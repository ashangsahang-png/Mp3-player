# Cassette — pemutar MP3

- Daftar lagu dibaca dari penyimpanan (MediaStore), cover diambil dari tag ID3 di dalam file MP3.
- Layar pemutar: latar blur dari cover, visualizer di belakang, kaset berputar dengan cover di labelnya.
- Berjalan di latar belakang dengan notifikasi (prev / play-pause / next).

## Build
Buka folder ini di Android Studio (Koala+), tunggu Gradle sync, lalu Run di HP (Android 8.0+).

## Izin
- Musik/audio: membaca daftar lagu.
- Mikrofon (RECORD_AUDIO): syarat dari Android agar Visualizer boleh membaca output audio pemutar. Mikrofon tidak direkam.
- Notifikasi: tombol kontrol di notifikasi (Android 13+).

## Build otomatis di GitHub
Workflow ada di `.github/workflows/build.yml`.
1. Buat repo baru di GitHub, lalu dari folder ini:
   `git init && git add . && git commit -m "first commit" && git branch -M main`
   `git remote add origin https://github.com/USERNAME/REPO.git && git push -u origin main`
2. Buka tab **Actions** di repo — build jalan otomatis. Bisa juga dijalankan manual lewat **Run workflow**.
3. Setelah hijau, buka run tersebut → bagian **Artifacts** → unduh `Cassette-debug-apk` (zip berisi APK).
4. Untuk membuat Release dengan APK terlampir: `git tag v1.0 && git push origin v1.0`.

APK yang dihasilkan adalah debug build (ditandatangani kunci debug) — bisa langsung di-install di HP
(izinkan "install dari sumber tidak dikenal").
