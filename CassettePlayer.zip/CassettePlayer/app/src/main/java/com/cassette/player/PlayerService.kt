package com.cassette.player

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import java.util.concurrent.Executors

/** Pemutar musik yang tetap jalan di latar belakang (foreground service + notifikasi dengan tombol). */
class PlayerService : Service() {

    inner class LocalBinder : Binder() { fun get(): PlayerService = this@PlayerService }
    private val binder = LocalBinder()

    var tracks: List<Track> = emptyList(); private set
    var index = -1; private set
    var art: Bitmap? = null; private set
    var onChange: (() -> Unit)? = null

    private var mp: MediaPlayer? = null
    private var fg = false
    private var resumeOnFocus = false
    private var focusReq: AudioFocusRequest? = null
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var nm: NotificationManager
    private lateinit var am: AudioManager

    val current: Track? get() = tracks.getOrNull(index)
    val isPlaying: Boolean get() = try { mp?.isPlaying == true } catch (_: Exception) { false }
    val position: Int get() = try { mp?.currentPosition ?: 0 } catch (_: Exception) { 0 }
    val duration: Int get() = try { mp?.duration ?: 0 } catch (_: Exception) { 0 }
    val audioSessionId: Int get() = try { mp?.audioSessionId ?: 0 } catch (_: Exception) { 0 }

    private val attrs = AudioAttributes.Builder()
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .build()

    private val noisy = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { pause() }
    }

    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        when (change) {
            AudioManager.AUDIOFOCUS_GAIN -> {
                mp?.setVolume(1f, 1f)
                if (resumeOnFocus) { resumeOnFocus = false; resume() }
            }
            AudioManager.AUDIOFOCUS_LOSS -> { resumeOnFocus = false; pause() }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> { resumeOnFocus = isPlaying; pause() }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> mp?.setVolume(0.25f, 0.25f)
        }
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        am = getSystemService(AUDIO_SERVICE) as AudioManager
        nm.createNotificationChannel(NotificationChannel(CH, "Pemutar musik", NotificationManager.IMPORTANCE_LOW))
        registerReceiver(noisy, IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY))
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        when (i?.action) {
            ACTION_PREV -> prev()
            ACTION_NEXT -> next()
            ACTION_TOGGLE -> toggle()
            ACTION_STOP -> stopAll()
            else -> if (!fg) startFg(buildNotification())
        }
        return START_NOT_STICKY
    }

    // ---------- kontrol ----------
    fun setQueue(list: List<Track>) { tracks = list }

    fun playAt(i: Int) {
        if (i !in tracks.indices) return
        releasePlayer()
        index = i
        art = null
        val t = tracks[i]
        val p = MediaPlayer()
        try {
            p.setAudioAttributes(attrs)
            p.setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
            p.setDataSource(applicationContext, t.uri)
            p.prepare()
        } catch (e: Exception) {
            p.release()
            onStateChanged()
            return
        }
        p.setOnCompletionListener { next() }
        p.setOnErrorListener { _, _, _ -> true }
        mp = p
        requestFocus()
        p.start()
        loadArt(t)
        onStateChanged()
    }

    fun next() { if (tracks.isNotEmpty()) playAt((index + 1) % tracks.size) }

    fun prev() {
        if (tracks.isEmpty()) return
        if (position > 3000) seekTo(0) else playAt((index - 1 + tracks.size) % tracks.size)
    }

    fun toggle() {
        if (mp == null) { if (index >= 0) playAt(index) }
        else if (isPlaying) pause() else resume()
    }

    fun pause() { val p = mp ?: return; if (p.isPlaying) p.pause(); onStateChanged() }

    fun resume() {
        val p = mp ?: return
        if (!p.isPlaying) { requestFocus(); p.start() }
        onStateChanged()
    }

    fun seekTo(ms: Int) { try { mp?.seekTo(ms) } catch (_: Exception) {} }

    private fun stopAll() {
        releasePlayer()
        index = -1
        art = null
        if (fg) { stopForeground(STOP_FOREGROUND_REMOVE); fg = false }
        nm.cancel(ID)
        onChange?.invoke()
        stopSelf()
    }

    private fun releasePlayer() {
        try { mp?.release() } catch (_: Exception) {}
        mp = null
        focusReq?.let { am.abandonAudioFocusRequest(it) }
        focusReq = null
    }

    private fun requestFocus() {
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(attrs)
            .setOnAudioFocusChangeListener(focusListener)
            .build()
        focusReq = req
        am.requestAudioFocus(req)
    }

    private fun loadArt(t: Track) {
        worker.execute {
            val b = Art.load(this, t)
            main.post {
                if (current?.id == t.id) {
                    art = b
                    updateNotification()
                    onChange?.invoke()
                }
            }
        }
    }

    private fun onStateChanged() { updateNotification(); onChange?.invoke() }

    // ---------- notifikasi ----------
    private fun updateNotification() {
        if (index < 0) return
        val n = buildNotification()
        if (isPlaying) startFg(n)
        else {
            if (fg) { stopForeground(STOP_FOREGROUND_DETACH); fg = false }
            nm.notify(ID, n)
        }
    }

    private fun startFg(n: Notification) {
        if (Build.VERSION.SDK_INT >= 29) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(ID, n)
        fg = true
    }

    private fun pi(action: String, code: Int): PendingIntent = PendingIntent.getService(
        this, code, Intent(this, PlayerService::class.java).setAction(action),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun act(icon: Int, label: String, action: String, code: Int) =
        Notification.Action.Builder(Icon.createWithResource(this, icon), label, pi(action, code)).build()

    private fun buildNotification(): Notification {
        val t = current
        val open = PendingIntent.getActivity(
            this, 0, packageManager.getLaunchIntentForPackage(packageName),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(t?.title ?: "Memuat…")
            .setContentText(t?.artist ?: "")
            .setLargeIcon(art)
            .setContentIntent(open)
            .setOnlyAlertOnce(true)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(act(android.R.drawable.ic_media_previous, "Sebelumnya", ACTION_PREV, 1))
            .addAction(
                if (isPlaying) act(android.R.drawable.ic_media_pause, "Jeda", ACTION_TOGGLE, 2)
                else act(android.R.drawable.ic_media_play, "Putar", ACTION_TOGGLE, 2)
            )
            .addAction(act(android.R.drawable.ic_media_next, "Berikutnya", ACTION_NEXT, 3))
            .setStyle(Notification.MediaStyle().setShowActionsInCompactView(0, 1, 2))
        if (!isPlaying) b.setDeleteIntent(pi(ACTION_STOP, 4))
        return b.build()
    }

    override fun onDestroy() {
        releasePlayer()
        try { unregisterReceiver(noisy) } catch (_: Exception) {}
        worker.shutdownNow()
        super.onDestroy()
    }

    companion object {
        const val CH = "cassette_player"
        const val ID = 7
        const val ACTION_PREV = "cassette.PREV"
        const val ACTION_NEXT = "cassette.NEXT"
        const val ACTION_TOGGLE = "cassette.TOGGLE"
        const val ACTION_STOP = "cassette.STOP"
    }
}
