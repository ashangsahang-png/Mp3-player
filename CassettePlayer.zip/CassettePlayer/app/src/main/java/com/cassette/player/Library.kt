package com.cassette.player

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore

object Library {
    /** Membaca semua audio (>= 30 detik, supaya nada dering tidak ikut) dari penyimpanan perangkat. */
    fun load(ctx: Context): List<Track> {
        val out = mutableListOf<Track>()
        val base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.DURATION
        )
        val sel = "${MediaStore.Audio.Media.DURATION} >= 30000 AND ${MediaStore.Audio.Media.MIME_TYPE} LIKE 'audio/%'"
        ctx.contentResolver.query(base, proj, sel, null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val iTitle = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val iArtist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val iDur = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                val artist = c.getString(iArtist)?.takeIf { it.isNotBlank() && it != "<unknown>" } ?: "Artis tidak diketahui"
                out += Track(id, c.getString(iTitle) ?: "Tanpa judul", artist, c.getLong(iDur), ContentUris.withAppendedId(base, id))
            }
        }
        return out
    }
}
