package com.cassette.player

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View

/** Batang equalizer di latar belakang, digerakkan oleh data FFT dari android.media.audiofx.Visualizer. */
class VisualizerView(ctx: Context) : View(ctx) {

    private val bars = 40
    private val target = FloatArray(bars)
    private val level = FloatArray(bars)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    var accent: Int = Color.WHITE

    fun feed(fft: ByteArray) {
        val n = fft.size / 2            // jumlah bin kompleks
        if (n < 8) return
        val top = n / 2                 // pakai separuh bawah spektrum (~0–11 kHz)
        for (b in 0 until bars) {
            val lo = 1 + ((top - 1) * Math.pow(b.toDouble() / bars, 2.0)).toInt()
            val hi = maxOf(lo + 1, 1 + ((top - 1) * Math.pow((b + 1).toDouble() / bars, 2.0)).toInt())
            var sum = 0f
            var cnt = 0
            for (k in lo until minOf(hi, n)) {
                val re = fft[2 * k].toDouble()
                val im = fft[2 * k + 1].toDouble()
                sum += Math.hypot(re, im).toFloat()
                cnt++
            }
            val m = if (cnt == 0) 0f else sum / cnt
            val v = Math.sqrt((m / 90f).toDouble()).toFloat() * (1f + 0.8f * b / bars)
            target[b] = v.coerceIn(0f, 1f)
        }
        postInvalidateOnAnimation()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val slot = w / bars
        val bw = slot * 0.62f
        var active = false
        for (i in 0 until bars) {
            val t = target[i]
            level[i] += (t - level[i]) * (if (t > level[i]) 0.6f else 0.18f)
            target[i] = t * 0.9f
            if (level[i] > 0.004f) active = true
            val bh = level[i] * h * 0.5f
            if (bh < 2f) continue
            paint.color = accent
            paint.alpha = (110 + 110 * level[i]).toInt().coerceAtMost(230)
            val x = i * slot + (slot - bw) / 2f
            rect.set(x, h - bh, x + bw, h)
            c.drawRoundRect(rect, bw / 2f, bw / 2f, paint)
        }
        if (active) postInvalidateOnAnimation()
    }
}
