package com.cassette.player

import android.content.Context
import android.graphics.*
import android.media.MediaMetadataRetriever

/** Mengambil gambar cover yang tertanam di file MP3, membuat versi blur, dan warna aksen. */
object Art {

    fun load(ctx: Context, t: Track): Bitmap {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, t.uri)
            val bytes = r.embeddedPicture
            if (bytes != null) {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
                var s = 1
                while (o.outWidth / s > 1000 || o.outHeight / s > 1000) s *= 2
                val o2 = BitmapFactory.Options().apply { inSampleSize = s }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2)?.let { return it }
            }
        } catch (_: Exception) {
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
        return placeholder(t)
    }

    /** Dipakai kalau MP3 tidak punya cover: gradasi warna unik per lagu. */
    fun placeholder(t: Track): Bitmap {
        val size = 600
        val b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val hue = (((t.title + t.artist).hashCode().toLong() and 0x7fffffffL) % 360).toFloat()
        val c1 = Color.HSVToColor(floatArrayOf(hue, 0.60f, 0.60f))
        val c2 = Color.HSVToColor(floatArrayOf((hue + 60f) % 360f, 0.70f, 0.28f))
        val g = Paint().apply { shader = LinearGradient(0f, 0f, size.toFloat(), size.toFloat(), c1, c2, Shader.TileMode.CLAMP) }
        c.drawRect(0f, 0f, size.toFloat(), size.toFloat(), g)
        val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x66FFFFFF; textSize = 300f; textAlign = Paint.Align.CENTER }
        c.drawText("♪", size / 2f, size / 2f + 100f, tp)
        return b
    }

    /** Bitmap kecil yang sudah di-blur; saat diperbesar oleh ImageView hasilnya halus. */
    fun blur(src: Bitmap): Bitmap {
        val w = 64
        val h = (w.toFloat() * src.height / src.width).toInt().coerceAtLeast(16)
        val mid = Bitmap.createScaledBitmap(src, w * 4, h * 4, true)
        val small = Bitmap.createScaledBitmap(mid, w, h, true).copy(Bitmap.Config.ARGB_8888, true)
        boxBlur(small, 3)
        boxBlur(small, 3)
        return small
    }

    fun accent(src: Bitmap): Int {
        val px = Bitmap.createScaledBitmap(src, 1, 1, true).getPixel(0, 0)
        val hsv = FloatArray(3)
        Color.colorToHSV(px, hsv)
        if (hsv[1] >= 0.12f) hsv[1] = maxOf(hsv[1], 0.45f)
        hsv[2] = maxOf(hsv[2], 0.85f)
        return Color.HSVToColor(hsv)
    }

    private fun boxBlur(b: Bitmap, r: Int) {
        val w = b.width; val h = b.height
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, 0, 0, w, h)
        val tmp = IntArray(w * h)
        val n = 2 * r + 1
        for (y in 0 until h) for (x in 0 until w) {
            var rr = 0; var g = 0; var bl = 0
            for (k in -r..r) {
                val p = px[y * w + (x + k).coerceIn(0, w - 1)]
                rr += (p shr 16) and 255; g += (p shr 8) and 255; bl += p and 255
            }
            tmp[y * w + x] = (255 shl 24) or ((rr / n) shl 16) or ((g / n) shl 8) or (bl / n)
        }
        for (y in 0 until h) for (x in 0 until w) {
            var rr = 0; var g = 0; var bl = 0
            for (k in -r..r) {
                val p = tmp[(y + k).coerceIn(0, h - 1) * w + x]
                rr += (p shr 16) and 255; g += (p shr 8) and 255; bl += p and 255
            }
            px[y * w + x] = (255 shl 24) or ((rr / n) shl 16) or ((g / n) shl 8) or (bl / n)
        }
        b.setPixels(px, 0, w, 0, 0, w, h)
    }
}
