package com.cassette.player

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.audiofx.Visualizer
import android.os.Build
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import java.util.concurrent.Executors

/** Layar pemutar penuh: latar blur dari cover, visualizer, kaset berputar, judul, seekbar, tombol. */
class NowPlayingView(private val ctx: Context) : FrameLayout(ctx) {

    var service: PlayerService? = null
    var onClose: (() -> Unit)? = null

    private val bgView = ImageView(ctx)
    private val viz = VisualizerView(ctx)
    private val cassette = CassetteView(ctx)
    private val titleTv = TextView(ctx)
    private val artistTv = TextView(ctx)
    private val curTv = TextView(ctx)
    private val durTv = TextView(ctx)
    private val seek = SeekBar(ctx)
    private val playBtn = ImageButton(ctx)
    private val io = Executors.newSingleThreadExecutor()

    private var visualizer: Visualizer? = null
    private var shown = false
    private var dragging = false
    private var shownId = -1L
    private var shownSession = -1
    private var shownArt: Bitmap? = null

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val tick = object : Runnable {
        override fun run() {
            val s = service
            if (shown && s != null) {
                val d = s.duration
                if (d > 0 && seek.max != d) { seek.max = d; durTv.text = fmtTime(d) }
                if (!dragging) { seek.progress = s.position; curTv.text = fmtTime(s.position) }
                cassette.progress = if (d > 0) s.position.toFloat() / d else 0f
            }
            if (shown) postDelayed(this, 250)
        }
    }

    init {
        setBackgroundColor(Color.BLACK)

        bgView.scaleType = ImageView.ScaleType.CENTER_CROP
        bgView.scaleX = 1.25f; bgView.scaleY = 1.25f
        if (Build.VERSION.SDK_INT >= 31) {
            bgView.setRenderEffect(RenderEffect.createBlurEffect(24f, 24f, Shader.TileMode.CLAMP))
        }
        addView(bgView, LayoutParams(MATCH, MATCH))
        addView(View(ctx).apply { setBackgroundColor(0x99000000.toInt()) }, LayoutParams(MATCH, MATCH))
        addView(viz, LayoutParams(MATCH, MATCH))

        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ctx.dp(20), ctx.dp(8), ctx.dp(20), ctx.dp(24))
        }

        val close = ImageButton(ctx).apply {
            setImageResource(android.R.drawable.arrow_down_float)
            setBackgroundColor(0)
            setColorFilter(Color.WHITE)
            setOnClickListener { onClose?.invoke() }
        }
        col.addView(close, LinearLayout.LayoutParams(ctx.dp(48), ctx.dp(48)))
        col.addView(View(ctx), LinearLayout.LayoutParams(MATCH, 0, 1f))
        col.addView(cassette, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(ctx.dp(4), 0, ctx.dp(4), 0) })
        col.addView(View(ctx), LinearLayout.LayoutParams(MATCH, 0, 0.6f))

        titleTv.apply {
            setTextColor(Color.WHITE); textSize = 22f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; setSingleLine(true); ellipsize = TextUtils.TruncateAt.END
        }
        artistTv.apply {
            setTextColor(0xCCFFFFFF.toInt()); textSize = 15f
            gravity = Gravity.CENTER; setSingleLine(true); ellipsize = TextUtils.TruncateAt.END
        }
        col.addView(titleTv, LinearLayout.LayoutParams(MATCH, WRAP))
        col.addView(artistTv, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = ctx.dp(4) })

        for (t in listOf(curTv, durTv)) { t.setTextColor(0xCCFFFFFF.toInt()); t.textSize = 12f; t.text = "0:00" }
        seek.progressTintList = ColorStateList.valueOf(Color.WHITE)
        seek.thumbTintList = ColorStateList.valueOf(Color.WHITE)
        seek.progressBackgroundTintList = ColorStateList.valueOf(0x55FFFFFF)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) { if (fromUser) curTv.text = fmtTime(p) }
            override fun onStartTrackingTouch(sb: SeekBar) { dragging = true }
            override fun onStopTrackingTouch(sb: SeekBar) { service?.seekTo(sb.progress); dragging = false }
        })
        val row = LinearLayout(ctx).apply { gravity = Gravity.CENTER_VERTICAL }
        row.addView(curTv)
        row.addView(seek, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(durTv)
        col.addView(row, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = ctx.dp(16) })

        val controls = LinearLayout(ctx).apply { gravity = Gravity.CENTER }
        controls.addView(iconBtn(android.R.drawable.ic_media_previous) { service?.prev() }, LinearLayout.LayoutParams(ctx.dp(64), ctx.dp(64)))
        playBtn.apply {
            setImageResource(android.R.drawable.ic_media_play)
            setColorFilter(Color.BLACK)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setPadding(ctx.dp(18), ctx.dp(18), ctx.dp(18), ctx.dp(18))
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE) }
            setOnClickListener { service?.toggle() }
        }
        controls.addView(playBtn, LinearLayout.LayoutParams(ctx.dp(76), ctx.dp(76)).apply { setMargins(ctx.dp(16), 0, ctx.dp(16), 0) })
        controls.addView(iconBtn(android.R.drawable.ic_media_next) { service?.next() }, LinearLayout.LayoutParams(ctx.dp(64), ctx.dp(64)))
        col.addView(controls, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = ctx.dp(12) })

        addView(col, LayoutParams(MATCH, MATCH))
    }

    private fun iconBtn(res: Int, click: () -> Unit) = ImageButton(ctx).apply {
        setImageResource(res)
        setBackgroundColor(0)
        setColorFilter(Color.WHITE)
        scaleType = ImageView.ScaleType.CENTER_INSIDE
        setPadding(ctx.dp(14), ctx.dp(14), ctx.dp(14), ctx.dp(14))
        setOnClickListener { click() }
    }

    fun show() {
        shown = true
        shownSession = -1
        refresh()
        removeCallbacks(tick)
        post(tick)
    }

    fun hide() {
        shown = false
        removeCallbacks(tick)
        releaseVisualizer()
        shownSession = -1
    }

    /** Dipanggil setiap kali service melapor perubahan (lagu ganti, play/pause, cover siap). */
    fun refresh() {
        if (!shown) return
        val s = service ?: return
        val t = s.current ?: return
        if (t.id != shownId) {
            shownId = t.id
            titleTv.text = t.title
            artistTv.text = t.artist
            cassette.title = t.title
            cassette.progress = 0f
            seek.progress = 0
            curTv.text = "0:00"
        }
        val d = s.duration
        if (d > 0 && seek.max != d) { seek.max = d; durTv.text = fmtTime(d) }
        val session = s.audioSessionId
        if (session != shownSession) { shownSession = session; attachVisualizer() }
        val a = s.art
        if (a != null && a !== shownArt) { shownArt = a; applyArt(a) }
        cassette.setSpinning(s.isPlaying)
        playBtn.setImageResource(if (s.isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
    }

    private fun applyArt(bmp: Bitmap) {
        cassette.art = bmp
        io.execute {
            val blurred = Art.blur(bmp)
            val accent = Art.accent(bmp)
            post {
                viz.accent = accent
                bgView.animate().alpha(0f).setDuration(150).withEndAction {
                    bgView.setImageBitmap(blurred)
                    bgView.animate().alpha(1f).setDuration(400).start()
                }.start()
            }
        }
    }

    // ---------- visualizer ----------
    private fun attachVisualizer() {
        releaseVisualizer()
        val s = service ?: return
        val sid = s.audioSessionId
        if (sid == 0) return
        if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        try {
            val v = Visualizer(sid)
            v.setCaptureSize(Visualizer.getCaptureSizeRange()[1].coerceAtMost(1024))
            v.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(vis: Visualizer?, wave: ByteArray?, rate: Int) {}
                override fun onFftDataCapture(vis: Visualizer?, fft: ByteArray?, rate: Int) { if (fft != null) viz.feed(fft) }
            }, Visualizer.getMaxCaptureRate() / 2, false, true)
            v.setEnabled(true)
            visualizer = v
        } catch (_: Exception) {
            visualizer = null
        }
    }

    private fun releaseVisualizer() {
        try { visualizer?.setEnabled(false); visualizer?.release() } catch (_: Exception) {}
        visualizer = null
    }
}
