package com.cassette.player

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.text.TextPaint
import android.text.TextUtils
import android.view.View
import android.view.animation.LinearInterpolator

/** Kaset yang digambar manual: cover MP3 di label, dua reel berputar saat lagu diputar. */
class CassetteView(ctx: Context) : View(ctx) {

    var art: Bitmap? = null
        set(v) { field = v; invalidate() }
    var title: String = ""
        set(v) { field = v; updateTitle(); invalidate() }
    /** 0..1 — pita berpindah dari reel kiri ke kanan mengikuti posisi lagu. */
    var progress: Float = 0f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }

    private var angle = 0f
    private val anim = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 2400
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { angle = it.animatedValue as Float; invalidate() }
    }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF2B2622.toInt()
        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
    }
    private val body = RectF()
    private val label = RectF()
    private val strip = RectF()
    private val win = RectF()
    private val tmp = RectF()
    private val src = Rect()
    private val labelPath = Path()
    private val trap = Path()
    private var drawTitle = ""

    fun setSpinning(on: Boolean) {
        if (on) {
            if (!anim.isStarted) anim.start() else if (anim.isPaused) anim.resume()
        } else if (anim.isRunning) anim.pause()
    }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val w = MeasureSpec.getSize(wSpec)
        setMeasuredDimension(w, (w / 1.6f).toInt())
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val W = w.toFloat(); val H = h.toFloat()
        body.set(0.02f * W, 0.02f * H, 0.98f * W, 0.93f * H)
        label.set(0.07f * W, 0.07f * H, 0.93f * W, 0.70f * H)
        strip.set(0.09f * W, 0.09f * H, 0.91f * W, 0.19f * H)
        win.set(0.27f * W, 0.45f * H, 0.73f * W, 0.65f * H)
        labelPath.reset()
        labelPath.addRoundRect(label, 0.03f * W, 0.03f * W, Path.Direction.CW)
        trap.reset()
        trap.moveTo(0.12f * W, 0.73f * H); trap.lineTo(0.88f * W, 0.73f * H)
        trap.lineTo(0.80f * W, 0.915f * H); trap.lineTo(0.20f * W, 0.915f * H); trap.close()
        updateTitle()
    }

    private fun updateTitle() {
        if (width == 0) return
        textPaint.textSize = height * 0.065f
        drawTitle = TextUtils.ellipsize(title, textPaint, strip.width() - width * 0.05f, TextUtils.TruncateAt.END).toString()
    }

    override fun onDraw(c: Canvas) {
        val W = width.toFloat(); val H = height.toFloat()
        val r = 0.045f * W

        // bayangan + badan kaset
        p.style = Paint.Style.FILL
        p.color = 0x66000000
        tmp.set(body); tmp.offset(0f, 0.025f * H)
        c.drawRoundRect(tmp, r, r, p)
        p.color = 0xFF25262B.toInt()
        c.drawRoundRect(body, r, r, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 0.004f * W; p.color = 0xFF40434B.toInt()
        c.drawRoundRect(body, r, r, p)
        p.style = Paint.Style.FILL

        // label dengan cover
        val bmp = art
        if (bmp != null) {
            val target = label.width() / label.height()
            val bw = bmp.width; val bh = bmp.height
            if (bw.toFloat() / bh > target) {
                val nw = (bh * target).toInt(); src.set((bw - nw) / 2, 0, (bw + nw) / 2, bh)
            } else {
                val nh = (bw / target).toInt(); src.set(0, (bh - nh) / 2, bw, (bh + nh) / 2)
            }
            c.save(); c.clipPath(labelPath); c.drawBitmap(bmp, src, label, bmpPaint); c.restore()
        } else {
            p.color = 0xFF3A3D46.toInt(); c.drawPath(labelPath, p)
        }
        // strip judul
        p.color = 0xEBF1E9D6.toInt()
        c.drawRoundRect(strip, 0.012f * W, 0.012f * W, p)
        c.drawText(drawTitle, strip.centerX(), strip.centerY() + textPaint.textSize * 0.35f, textPaint)

        // jendela pita
        p.color = 0xF0121316.toInt()
        c.drawRoundRect(win, 0.06f * H, 0.06f * H, p)

        val cy = 0.55f * H
        val cxL = 0.38f * W; val cxR = 0.62f * W
        val hubR = 0.05f * H; val maxR = 0.095f * H
        val rl = hubR + (maxR - hubR) * (1f - 0.85f * progress)
        val rr = hubR + (maxR - hubR) * (0.15f + 0.85f * progress)

        // gulungan pita
        p.color = 0xFF4A3426.toInt()
        c.drawCircle(cxL, cy, rl, p)
        c.drawCircle(cxR, cy, rr, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 0.004f * H; p.color = 0xFF6B4E3A.toInt()
        c.drawCircle(cxL, cy, rl, p)
        c.drawCircle(cxR, cy, rr, p)
        p.strokeWidth = 0.008f * H; p.color = 0xFF4A3426.toInt()
        c.drawLine(cxL, cy + rl, cxR, cy + rr, p)
        p.style = Paint.Style.FILL

        drawReel(c, cxL, cy, hubR)
        drawReel(c, cxR, cy, hubR)

        // bagian bawah (trapesium) + lubang
        p.color = 0xFF1A1B1F.toInt(); c.drawPath(trap, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 0.004f * W; p.color = 0xFF40434B.toInt(); c.drawPath(trap, p)
        p.style = Paint.Style.FILL
        p.color = 0xFF0B0B0D.toInt()
        c.drawCircle(0.31f * W, 0.82f * H, 0.028f * H, p)
        c.drawCircle(0.69f * W, 0.82f * H, 0.028f * H, p)
        tmp.set(0.44f * W, 0.79f * H, 0.56f * W, 0.85f * H)
        c.drawRoundRect(tmp, 0.01f * H, 0.01f * H, p)

        // sekrup di sudut
        p.color = 0xFF5A5D66.toInt()
        val sr = 0.012f * W
        c.drawCircle(0.045f * W, 0.065f * H, sr, p)
        c.drawCircle(0.955f * W, 0.065f * H, sr, p)
        c.drawCircle(0.045f * W, 0.885f * H, sr, p)
        c.drawCircle(0.955f * W, 0.885f * H, sr, p)
    }

    private fun drawReel(c: Canvas, cx: Float, cy: Float, hubR: Float) {
        p.color = 0xFFE9E9EC.toInt(); c.drawCircle(cx, cy, hubR, p)
        p.color = 0xFF16171A.toInt(); c.drawCircle(cx, cy, hubR * 0.62f, p)
        p.color = 0xFFE9E9EC.toInt()
        for (i in 0 until 6) {
            c.save()
            c.rotate(angle + i * 60f, cx, cy)
            tmp.set(cx - hubR * 0.10f, cy - hubR * 0.64f, cx + hubR * 0.10f, cy - hubR * 0.36f)
            c.drawRect(tmp, p)
            c.restore()
        }
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }
}
