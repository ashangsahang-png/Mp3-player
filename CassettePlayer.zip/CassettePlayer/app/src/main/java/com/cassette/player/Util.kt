package com.cassette.player

import android.content.Context
import android.net.Uri

data class Track(val id: Long, val title: String, val artist: String, val durationMs: Long, val uri: Uri)

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun fmtTime(ms: Int): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}
