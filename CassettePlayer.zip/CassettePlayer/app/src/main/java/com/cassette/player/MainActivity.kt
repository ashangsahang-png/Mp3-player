package com.cassette.player

import android.Manifest
import android.animation.ObjectAnimator
import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private var service: PlayerService? = null
    private var tracks: List<Track> = emptyList()

    private lateinit var countTv: TextView
    private lateinit var list: ListView
    private lateinit var adapter: ArrayAdapter<Track>
    private lateinit var mini: LinearLayout
    private lateinit var miniTitle: TextView
    private lateinit var miniArtist: TextView
    private lateinit var miniBtn: ImageButton
    private lateinit var now: NowPlayingView

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName, b: IBinder) {
            val s = (b as PlayerService.LocalBinder).get()
            service = s
            s.onChange = { onPlayerChange() }
            now.service = s
            onPlayerChange()
        }
        override fun onServiceDisconnected(n: ComponentName) { service = null; now.service = null }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#0E0F12")
        window.navigationBarColor = Color.parseColor("#0E0F12")
        buildUi()
        bindService(Intent(this, PlayerService::class.java), conn, Context.BIND_AUTO_CREATE)
        requestPerms()
    }

    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#0E0F12")); fitsSystemWindows = true }

        val library = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        library.addView(TextView(this).apply {
            text = "Cassette"; textSize = 30f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(20), dp(20), dp(20), 0)
        })
        countTv = TextView(this).apply {
            textSize = 14f; setTextColor(0xFF8B93A1.toInt()); setPadding(dp(20), dp(2), dp(20), dp(12))
        }
        library.addView(countTv)

        adapter = object : ArrayAdapter<Track>(this, android.R.layout.simple_list_item_2, android.R.id.text1, ArrayList()) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getView(position, convertView, parent)
                val t = getItem(position)!!
                val playing = service?.current?.id == t.id
                v.findViewById<TextView>(android.R.id.text1).apply {
                    text = t.title; setTextColor(if (playing) 0xFF7CFFB2.toInt() else Color.WHITE); setSingleLine(true)
                }
                v.findViewById<TextView>(android.R.id.text2).apply {
                    text = "${t.artist} • ${fmtTime(t.durationMs.toInt())}"; setTextColor(0xFF8B93A1.toInt()); setSingleLine(true)
                }
                v.setPadding(dp(20), dp(8), dp(20), dp(8))
                return v
            }
        }
        list = ListView(this).apply {
            adapter = this@MainActivity.adapter
            divider = null
            setOnItemClickListener { _, _, pos, _ -> play(pos) }
        }
        library.addView(list, LinearLayout.LayoutParams(MATCH, 0, 1f))

        miniTitle = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setSingleLine(true)
        }
        miniArtist = TextView(this).apply { setTextColor(0xFF8B93A1.toInt()); textSize = 12f; setSingleLine(true) }
        miniBtn = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_media_play); setBackgroundColor(0); setColorFilter(Color.WHITE)
            setOnClickListener { service?.toggle() }
        }
        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(miniTitle); addView(miniArtist)
        }
        mini = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#1A1C22"))
            setPadding(dp(20), dp(8), dp(8), dp(8))
            visibility = View.GONE
            setOnClickListener { openNowPlaying() }
            addView(texts, LinearLayout.LayoutParams(0, WRAP, 1f))
            addView(miniBtn, LinearLayout.LayoutParams(dp(48), dp(48)))
        }
        library.addView(mini, LinearLayout.LayoutParams(MATCH, WRAP))

        now = NowPlayingView(this).apply { visibility = View.GONE; onClose = { closeNowPlaying() } }

        root.addView(library, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(now, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(root)
    }

    // ---------- izin & daftar lagu ----------
    private fun audioPerm() =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun requestPerms() {
        val want = mutableListOf(audioPerm(), Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) want += Manifest.permission.POST_NOTIFICATIONS
        val missing = want.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) loadLibrary() else requestPermissions(missing.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (checkSelfPermission(audioPerm()) == PackageManager.PERMISSION_GRANTED) loadLibrary()
        else countTv.text = "Izin membaca musik diperlukan untuk menampilkan daftar lagu."
    }

    private fun loadLibrary() {
        Executors.newSingleThreadExecutor().execute {
            val found = Library.load(this)
            runOnUiThread {
                tracks = found
                adapter.clear(); adapter.addAll(found)
                countTv.text = if (found.isEmpty()) "Tidak ada lagu. Salin file MP3 ke folder Music lalu buka ulang aplikasi."
                else "${found.size} lagu"
            }
        }
    }

    // ---------- pemutaran ----------
    private fun play(pos: Int) {
        val s = service ?: return
        startForegroundService(Intent(this, PlayerService::class.java))
        s.setQueue(tracks)
        s.playAt(pos)
        openNowPlaying()
    }

    private fun onPlayerChange() {
        val s = service ?: return
        val t = s.current
        if (t == null) mini.visibility = View.GONE
        else {
            mini.visibility = View.VISIBLE
            miniTitle.text = t.title
            miniArtist.text = t.artist
            miniBtn.setImageResource(if (s.isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
        }
        adapter.notifyDataSetChanged()
        now.refresh()
    }

    private fun openNowPlaying() {
        if (service?.current == null) return
        now.visibility = View.VISIBLE
        now.show()
        ObjectAnimator.ofFloat(now, View.ALPHA, 0f, 1f).setDuration(250).start()
    }

    private fun closeNowPlaying() {
        now.hide()
        now.visibility = View.GONE
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (now.visibility == View.VISIBLE) closeNowPlaying() else super.onBackPressed()
    }

    override fun onDestroy() {
        now.hide()
        service?.onChange = null
        try { unbindService(conn) } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()
}
