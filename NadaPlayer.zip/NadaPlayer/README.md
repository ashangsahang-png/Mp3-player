# Nada Player

Pemutar MP3 untuk Android (Kotlin, tanpa dependensi tambahan).

- Daftar lagu: tab Lagu / Album / Artis / Favorit + pencarian. Thumbnail dari cover yang tertanam di MP3.
- Layar pemutar: piringan hitam berputar dengan cover MP3 di labelnya. Tonearm (stik) di bawah turun menyentuh
  alur saat lagu diputar dan terangkat saat jeda. Visualizer berupa cincin di sekeliling piringan.
- Ikon baju (kanan atas): ganti tema. Tombol "+" di dalamnya membuat tema sendiri (warna aksen + warna latar).
  Latar layar pemutar bisa: blur cover, gradasi tema, atau gambar dari galeri.
- Widget layar utama: cover, judul, artis, tombol sebelumnya / putar-jeda / berikutnya.
- Shuffle, repeat (semua / satu lagu), favorit, timer tidur, equalizer sistem, notifikasi kontrol.

## Build di GitHub
1. Buat repo, buat file `.github/workflows/build.yml` (isi dari file build.yml).
2. Upload `NadaPlayer.zip` ke root repo (tanpa diekstrak). Workflow mengekstraknya sendiri.
3. Tab Actions -> tunggu hijau -> Artifacts -> `NadaPlayer-debug-apk`.

## Build di Android Studio
Buka folder `NadaPlayer`, tunggu Gradle sync, Run.
