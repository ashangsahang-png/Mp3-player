# Nada Player

Pemutar MP3 untuk Android (Kotlin, tanpa dependensi tambahan).

- Daftar lagu dengan tab Lagu / Album / Artis / Favorit + pencarian. Thumbnail diambil dari cover yang tertanam di MP3.
- Layar pemutar: latar blur dari cover, cakram cover berputar dengan cincin visualizer, shuffle / repeat, favorit, timer tidur.
- Ikon hijau di layar pemutar: antrean (kembali ke daftar), equalizer sistem, volume, ganti gaya visualizer (cincin / gelombang neon / batang).
- Jalan di latar belakang dengan notifikasi berisi tombol kontrol.

## Build di GitHub
1. Buat repo, buat file `.github/workflows/build.yml` (isi dari file build.yml).
2. Upload `NadaPlayer.zip` ke root repo (tanpa diekstrak). Workflow mengekstraknya sendiri.
3. Tab Actions -> tunggu hijau -> Artifacts -> `NadaPlayer-debug-apk`.

## Build di Android Studio
Buka folder `NadaPlayer`, tunggu Gradle sync, Run.
