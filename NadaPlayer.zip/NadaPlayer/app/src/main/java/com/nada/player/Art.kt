package com.nada.player

import android.content.Context
import android.graphics.*
import android.media.MediaMetadataRetriever
import android.util.LruCache
import android.os.Handler
import android.os.Looper
import java.util.concurrent.Executors

/** Semua gambar diambil dari tag ID3 yang tertanam di file MP3 (embedded picture). */
object Art {

    private fun embedded(ctx: Context, t: Track): ByteArray? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, t.uri)
            r.embeddedPicture
        } catch (_: Exception) {
            null
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
    }

    private fun decode(bytes: ByteArray, maxSide: Int): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        var s = 1
        while (o.outWidth / (s * 2) >= maxSide && o.outHeight / (s * 2) >= maxSide) s *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = s }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2)
    }

    /** Cover ukuran besar untuk layar pemutar. Kalau MP3 tidak punya cover → gradasi warna. */
    fun load(ctx: Context, t: Track): Bitmap {
        val bytes = embedded(ctx, t)
        if (bytes != null) {
            val b = decode(bytes, 900)
            if (b != null) return b
        }
        return placeholder(t, 600)
    }

    /** Thumbnail persegi kecil untuk daftar lagu. */
    fun thumb(ctx: Context, t: Track, size: Int): Bitmap {
        val bytes = embedded(ctx, t)
        val src = if (bytes != null) decode(bytes, size) else null
        if (src == null) return placeholder(t, size)
        val side = minOf(src.width, src.height)
        val sq = Bitmap.createBitmap(src, (src.width - side) / 2, (src.height - side) / 2, side, side)
        return if (side == size) sq else Bitmap.createScaledBitmap(sq, size, size, true)
    }

    fun hasCover(ctx: Context, t: Track): Boolean = embedded(ctx, t) != null

    /** Dipakai kalau MP3 tidak punya cover: gradasi warna unik per lagu. */
    fun placeholder(t: Track, size: Int): Bitmap {
        val b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val hue = (((t.album + t.artist).hashCode().toLong() and 0x7fffffffL) % 360).toFloat()
        val c1 = Color.HSVToColor(floatArrayOf(hue, 0.60f, 0.60f))
        val c2 = Color.HSVToColor(floatArrayOf((hue + 60f) % 360f, 0.70f, 0.28f))
        val g = Paint().apply {
            shader = LinearGradient(0f, 0f, size.toFloat(), size.toFloat(), c1, c2, Shader.TileMode.CLAMP)
        }
        c.drawRect(0f, 0f, size.toFloat(), size.toFloat(), g)
        val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0x66FFFFFF; textSize = size * 0.5f; textAlign = Paint.Align.CENTER
        }
        c.drawText("♪", size / 2f, size / 2f + size * 0.17f, tp)
        return b
    }

    /** Bitmap kecil yang sudah di-blur; saat diperbesar oleh ImageView hasilnya halus. */
    fun blur(src: Bitmap): Bitmap {
        val w = 64
        val h = (w.toFloat() * src.height / src.width).toInt().coerceAtLeast(16)
        val mid = Bitmap.createScaledBitmap(src, w * 4, h * 4, true)
        val small = Bitmap.createScaledBitmap(mid, w, h, true).copy(Bitmap.Config.ARGB_8888, true)
        boxBlur(small, 3)
        boxBlur(small, 3)
        return small
    }

    fun accent(src: Bitmap): Int {
        val px = Bitmap.createScaledBitmap(src, 1, 1, true).getPixel(0, 0)
        val hsv = FloatArray(3)
        Color.colorToHSV(px, hsv)
        if (hsv[1] >= 0.12f) hsv[1] = maxOf(hsv[1], 0.45f)
        hsv[2] = maxOf(hsv[2], 0.85f)
        return Color.HSVToColor(hsv)
    }

    private fun boxBlur(b: Bitmap, r: Int) {
        val w = b.width
        val h = b.height
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, 0, 0, w, h)
        val tmp = IntArray(w * h)
        val n = 2 * r + 1
        for (y in 0 until h) for (x in 0 until w) {
            var rr = 0; var g = 0; var bl = 0
            for (k in -r..r) {
                val p = px[y * w + (x + k).coerceIn(0, w - 1)]
                rr += (p shr 16) and 255; g += (p shr 8) and 255; bl += p and 255
            }
            tmp[y * w + x] = (255 shl 24) or ((rr / n) shl 16) or ((g / n) shl 8) or (bl / n)
        }
        for (y in 0 until h) for (x in 0 until w) {
            var rr = 0; var g = 0; var bl = 0
            for (k in -r..r) {
                val p = tmp[(y + k).coerceIn(0, h - 1) * w + x]
                rr += (p shr 16) and 255; g += (p shr 8) and 255; bl += p and 255
            }
            px[y * w + x] = (255 shl 24) or ((rr / n) shl 16) or ((g / n) shl 8) or (bl / n)
        }
        b.setPixels(px, 0, w, 0, 0, w, h)
    }
}

/** Cache + pemuat thumbnail asinkron untuk daftar lagu. */
object Thumbs {
    private val cache = LruCache<Long, Bitmap>(150)
    private val pool = Executors.newFixedThreadPool(2)
    private val main = Handler(Looper.getMainLooper())

    fun cached(id: Long): Bitmap? = cache.get(id)

    fun load(ctx: Context, t: Track, size: Int, done: (Bitmap) -> Unit) {
        val hit = cache.get(t.id)
        if (hit != null) { done(hit); return }
        val app = ctx.applicationContext
        pool.execute {
            val b = Art.thumb(app, t, size)
            cache.put(t.id, b)
            main.post { done(b) }
        }
    }
}
