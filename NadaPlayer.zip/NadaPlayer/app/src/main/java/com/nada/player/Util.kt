package com.nada.player

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri

data class Track(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val uri: Uri
)

val GREEN: Int = 0xFF1ED760.toInt()
val BG: Int = 0xFF0A0C1B.toInt()
val CARD: Int = 0xFF161A31.toInt()
val MUTED: Int = 0xFF8B93A8.toInt()

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density

fun fmtTime(ms: Int): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

/** Daftar lagu favorit, disimpan di SharedPreferences. */
object Favorites {
    private var sp: SharedPreferences? = null
    private val ids = HashSet<String>()

    fun init(ctx: Context) {
        if (sp != null) return
        sp = ctx.applicationContext.getSharedPreferences("favorites", Context.MODE_PRIVATE)
        ids.addAll(sp!!.getStringSet("ids", emptySet()) ?: emptySet())
    }

    fun has(id: Long): Boolean = ids.contains(id.toString())

    fun toggle(id: Long): Boolean {
        val k = id.toString()
        val on = if (ids.contains(k)) { ids.remove(k); false } else { ids.add(k); true }
        sp?.edit()?.putStringSet("ids", HashSet(ids))?.apply()
        return on
    }
}
