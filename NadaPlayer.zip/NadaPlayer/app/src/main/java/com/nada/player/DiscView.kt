package com.nada.player

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View
import android.view.animation.LinearInterpolator

/** Cover album berbentuk lingkaran yang berputar pelan saat lagu diputar. */
class DiscView(ctx: Context) : View(ctx) {

    var art: Bitmap? = null
        set(v) {
            field = v
            shader = v?.let { BitmapShader(it, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP) }
            invalidate()
        }

    private var shader: BitmapShader? = null
    private var angle = 0f
    private val m = Matrix()
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = 0x55FFFFFF; strokeWidth = ctx.dpf(2f)
    }
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x55000000 }
    private val anim = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 24000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { angle = it.animatedValue as Float; invalidate() }
    }

    fun setSpinning(on: Boolean) {
        if (on) {
            if (!anim.isStarted) anim.start() else if (anim.isPaused) anim.resume()
        } else if (anim.isRunning) anim.pause()
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(width, height) / 2f - dpPx(3f)
        c.drawCircle(cx, cy + dpPx(5f), r, shadow)
        val bmp = art
        val sh = shader
        if (bmp != null && sh != null) {
            val side = minOf(bmp.width, bmp.height).toFloat()
            val sc = 2f * r / side
            m.reset()
            m.setScale(sc, sc)
            m.postTranslate(cx - bmp.width * sc / 2f, cy - bmp.height * sc / 2f)
            m.postRotate(angle, cx, cy)
            sh.setLocalMatrix(m)
            fillPaint.shader = sh
            c.drawCircle(cx, cy, r, fillPaint)
        } else {
            fillPaint.shader = null
            fillPaint.color = 0xFF2A2E48.toInt()
            c.drawCircle(cx, cy, r, fillPaint)
        }
        c.drawCircle(cx, cy, r, ringPaint)
    }

    private fun dpPx(v: Float) = v * resources.displayMetrics.density

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }
}
