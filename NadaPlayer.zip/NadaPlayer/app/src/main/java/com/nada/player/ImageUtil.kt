package com.nada.player

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri

/** Membaca gambar dari galeri (content://) dengan ukuran dikecilkan. */
fun decodeImage(ctx: Context, uri: String, maxSide: Int): Bitmap? {
    return try {
        val u = Uri.parse(uri)
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (o.outWidth / (s * 2) >= maxSide && o.outHeight / (s * 2) >= maxSide) s *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = s }
        ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o2) }
    } catch (_: Exception) {
        null
    }
}
