package com.nada.player

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color

class AppTheme(
    val id: String,
    val name: String,
    val accent: Int,
    val bg: Int,
    val card: Int,
    val gTop: Int,
    val gBottom: Int,
    val custom: Boolean = false
)

/** Tema aplikasi: warna aksen, latar, dan mode latar layar pemutar. Disimpan di SharedPreferences. */
object Themes {
    val presets: List<AppTheme> = listOf(
        AppTheme("hijau", "Hijau Malam", 0xFF1ED760.toInt(), 0xFF0A0C1B.toInt(), 0xFF161A31.toInt(), 0xFF1B2A6B.toInt(), 0xFF070916.toInt()),
        AppTheme("sunset", "Sunset", 0xFFFFD54F.toInt(), 0xFF160D08.toInt(), 0xFF2A1810.toInt(), 0xFFFF7A00.toInt(), 0xFF5E7D00.toInt()),
        AppTheme("samudra", "Samudra", 0xFF4FC3F7.toInt(), 0xFF06121F.toInt(), 0xFF0E2236.toInt(), 0xFF0B5FA8.toInt(), 0xFF031B34.toInt()),
        AppTheme("sakura", "Sakura", 0xFFFF6FA5.toInt(), 0xFF1A0B14.toInt(), 0xFF2A1422.toInt(), 0xFFC2347A.toInt(), 0xFF3A0F2A.toInt()),
        AppTheme("ungu", "Ungu Neon", 0xFFB388FF.toInt(), 0xFF0D0820.toInt(), 0xFF1B1238.toInt(), 0xFF6A35E8.toInt(), 0xFF150A3A.toInt()),
        AppTheme("amoled", "AMOLED", 0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFF121212.toInt(), 0xFF1A1A1A.toInt(), 0xFF000000.toInt())
    )

    val custom = ArrayList<AppTheme>()
    var selectedId = "hijau"
    /** Latar layar pemutar: 0 = blur cover, 1 = gradasi tema, 2 = gambar sendiri */
    var mode = 0
    var bgUri: String? = null
    /** Dipakai agar layar pemutar terbuka lagi setelah Activity dibuat ulang karena ganti tema. */
    var reopenNow = false

    private var sp: SharedPreferences? = null

    val all: List<AppTheme> get() = presets + custom
    val selected: AppTheme get() = all.firstOrNull { it.id == selectedId } ?: presets[0]

    fun init(ctx: Context) {
        if (sp == null) {
            val p = ctx.applicationContext.getSharedPreferences("theme", Context.MODE_PRIVATE)
            sp = p
            selectedId = p.getString("selected", "hijau") ?: "hijau"
            mode = p.getInt("mode", 0)
            bgUri = p.getString("bgUri", null)
            custom.clear()
            for (line in (p.getString("custom", "") ?: "").split("\n")) {
                val f = line.split("|")
                if (f.size == 7) {
                    try {
                        custom.add(AppTheme(f[0], f[1], f[2].toInt(), f[3].toInt(), f[4].toInt(), f[5].toInt(), f[6].toInt(), true))
                    } catch (_: Exception) {}
                }
            }
        }
        apply()
    }

    fun apply() {
        val t = selected
        GREEN = t.accent
        BG = t.bg
        CARD = t.card
    }

    fun select(id: String) { selectedId = id; save(); apply() }

    fun setMode(m: Int, uri: String? = null) {
        mode = m
        if (uri != null) bgUri = uri
        save()
    }

    /** Membuat warna tema dari dua pilihan hue (0..360): aksen dan latar. */
    fun make(name: String, accentHue: Float, bgHue: Float, id: String): AppTheme {
        fun hsv(h: Float, s: Float, v: Float) = Color.HSVToColor(floatArrayOf(h, s, v))
        return AppTheme(
            id, name,
            hsv(accentHue, 0.62f, 1f),
            hsv(bgHue, 0.55f, 0.10f),
            hsv(bgHue, 0.45f, 0.20f),
            hsv(bgHue, 0.75f, 0.58f),
            hsv(bgHue, 0.80f, 0.14f),
            true
        )
    }

    fun addCustom(t: AppTheme) { custom.add(t); selectedId = t.id; save(); apply() }

    fun remove(id: String) {
        custom.removeAll { it.id == id }
        if (selectedId == id) selectedId = "hijau"
        save(); apply()
    }

    private fun save() {
        val lines = custom.joinToString("\n") {
            listOf(it.id, it.name.replace("|", " ").replace("\n", " "), it.accent, it.bg, it.card, it.gTop, it.gBottom).joinToString("|")
        }
        sp?.edit()?.putString("selected", selectedId)?.putInt("mode", mode)?.putString("bgUri", bgUri)?.putString("custom", lines)?.apply()
    }
}
