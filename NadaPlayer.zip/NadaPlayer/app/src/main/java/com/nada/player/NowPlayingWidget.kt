package com.nada.player

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.widget.RemoteViews

/** Widget layar utama: cover, judul, artis, dan tombol sebelumnya / putar-jeda / berikutnya. */
class NowPlayingWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        for (id in ids) mgr.updateAppWidget(id, build(ctx))
    }

    companion object {
        private var title = ""
        private var artist = ""
        private var playing = false
        private var srcArt: Bitmap? = null
        private var smallArt: Bitmap? = null

        /** Dipanggil PlayerService setiap kali lagu / status putar / cover berubah. */
        fun push(ctx: Context, t: Track?, art: Bitmap?, isPlaying: Boolean) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, NowPlayingWidget::class.java))
            if (ids.isEmpty()) return
            title = t?.title ?: ""
            artist = t?.artist ?: ""
            playing = isPlaying && t != null
            if (art !== srcArt) {
                srcArt = art
                smallArt = if (art == null) null else Bitmap.createScaledBitmap(art, 192, 192, true)
            }
            mgr.updateAppWidget(ids, build(ctx))
        }

        private fun build(ctx: Context): RemoteViews {
            val v = RemoteViews(ctx.packageName, R.layout.widget_now_playing)
            v.setTextViewText(R.id.w_title, if (title.isEmpty()) "Nada Player" else title)
            v.setTextViewText(R.id.w_artist, if (artist.isEmpty()) "Ketuk ▶ untuk memutar" else artist)
            val a = smallArt
            if (a != null) v.setImageViewBitmap(R.id.w_art, a)
            else v.setImageViewResource(R.id.w_art, R.drawable.ic_launcher_bg)
            v.setImageViewResource(
                R.id.w_play,
                if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
            )
            v.setOnClickPendingIntent(R.id.w_prev, svc(ctx, PlayerService.ACTION_PREV, 11))
            v.setOnClickPendingIntent(R.id.w_play, svc(ctx, PlayerService.ACTION_TOGGLE, 12))
            v.setOnClickPendingIntent(R.id.w_next, svc(ctx, PlayerService.ACTION_NEXT, 13))
            val open = PendingIntent.getActivity(
                ctx, 14, ctx.packageManager.getLaunchIntentForPackage(ctx.packageName),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            v.setOnClickPendingIntent(R.id.w_root, open)
            return v
        }

        private fun svc(ctx: Context, action: String, code: Int): PendingIntent =
            PendingIntent.getForegroundService(
                ctx, code,
                Intent(ctx, PlayerService::class.java).setAction(action).putExtra(PlayerService.EXTRA_FG, true),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
    }
}
