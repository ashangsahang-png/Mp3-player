package com.nada.player

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.LinearInterpolator
import kotlin.math.atan2
import kotlin.math.hypot

/**
 * Piringan hitam berputar dengan cover MP3 di labelnya, plus tonearm (stik) yang pangkalnya
 * di bawah. Saat lagu diputar jarumnya turun menyentuh alur piringan; saat jeda jarumnya terangkat.
 */
class VinylView(ctx: Context) : View(ctx) {

    var art: Bitmap? = null
        set(v) {
            field = v
            shader = v?.let { BitmapShader(it, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP) }
            invalidate()
        }
    var accent: Int = GREEN
        set(v) { field = v; invalidate() }
    /** 0..1: posisi lagu — jarum bergeser pelan ke dalam seperti pemutar piringan sungguhan. */
    var progress: Float = 0f
        set(v) { field = v.coerceIn(0f, 1f); if (lift < 1f) invalidate() }

    var recordX = 0f
        private set
    var recordY = 0f
        private set
    var recordR = 0f
        private set

    private var shader: BitmapShader? = null
    private var spin = 0f
    private var lift = LIFT
    private var playing = false
    private val m = Matrix()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val rect = RectF()
    private var sweep: SweepGradient? = null
    private var base: RadialGradient? = null
    private var px = 0f
    private var py = 0f
    private var armLen = 0f
    private var baseDeg = 0f

    private val spinAnim = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 7000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { spin = it.animatedValue as Float; invalidate() }
    }
    private var armAnim: ValueAnimator? = null

    fun setPlaying(on: Boolean) {
        if (on == playing) return
        playing = on
        if (on) {
            if (!spinAnim.isStarted) spinAnim.start() else if (spinAnim.isPaused) spinAnim.resume()
        } else if (spinAnim.isRunning) spinAnim.pause()
        armAnim?.cancel()
        val a = ValueAnimator.ofFloat(lift, if (on) 0f else LIFT)
        a.duration = 650
        a.interpolator = AccelerateDecelerateInterpolator()
        a.addUpdateListener { lift = it.animatedValue as Float; invalidate() }
        a.start()
        armAnim = a
    }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val w = MeasureSpec.getSize(wSpec)
        setMeasuredDimension(w, (w * 1.16f).toInt())
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val W = w.toFloat()
        recordX = W / 2f
        recordY = W / 2f
        recordR = 0.455f * W
        sweep = SweepGradient(
            recordX, recordY,
            intArrayOf(0x00FFFFFF, 0x55FFFFFF, 0x00FFFFFF, 0x00FFFFFF, 0x44FFFFFF, 0x00FFFFFF),
            floatArrayOf(0f, 0.08f, 0.2f, 0.5f, 0.58f, 0.7f)
        )
        base = RadialGradient(
            recordX, recordY, recordR,
            intArrayOf(0xFF2A2A2E.toInt(), 0xFF111114.toInt(), 0xFF050506.toInt()),
            floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP
        )
        // pangkal tonearm di kanan-bawah; ujung jarum mendarat di alur piringan
        px = 0.90f * W
        py = 1.0f * W
        val tx = 0.755f * W
        val ty = 0.755f * W
        baseDeg = Math.toDegrees(atan2((ty - py).toDouble(), (tx - px).toDouble())).toFloat()
        armLen = hypot((tx - px).toDouble(), (ty - py).toDouble()).toFloat()
    }

    override fun onDraw(c: Canvas) {
        val W = width.toFloat()
        if (W <= 0f) return

        // bayangan
        p.style = Paint.Style.FILL
        p.shader = null
        p.color = 0x66000000
        c.drawCircle(recordX, recordY + 0.018f * W, recordR, p)

        // badan piringan
        p.shader = base
        c.drawCircle(recordX, recordY, recordR, p)
        p.shader = null

        // alur
        p.style = Paint.Style.STROKE
        p.strokeWidth = 0.0016f * W
        var r = 0.64f * recordR
        var i = 0
        while (r < recordR * 0.975f) {
            p.color = if (i % 9 == 0) 0x30FFFFFF else 0x14FFFFFF
            c.drawCircle(recordX, recordY, r, p)
            r += 0.0085f * W
            i++
        }

        // kilau (diam, supaya terlihat seperti pantulan cahaya)
        p.style = Paint.Style.FILL
        p.shader = sweep
        c.drawCircle(recordX, recordY, recordR, p)
        p.shader = null

        // tepi
        p.style = Paint.Style.STROKE
        p.strokeWidth = 0.006f * W
        p.color = 0xFF2E2E33.toInt()
        c.drawCircle(recordX, recordY, recordR - 0.003f * W, p)

        // label = cover MP3 (ikut berputar)
        val lr = recordR * 0.60f
        val bmp = art
        val sh = shader
        if (bmp != null && sh != null) {
            val side = minOf(bmp.width, bmp.height).toFloat()
            val sc = 2f * lr / side
            m.reset()
            m.setScale(sc, sc)
            m.postTranslate(recordX - bmp.width * sc / 2f, recordY - bmp.height * sc / 2f)
            m.postRotate(spin, recordX, recordY)
            sh.setLocalMatrix(m)
            bmpPaint.shader = sh
            c.drawCircle(recordX, recordY, lr, bmpPaint)
        } else {
            p.style = Paint.Style.FILL
            p.color = accent
            c.drawCircle(recordX, recordY, lr, p)
        }
        p.style = Paint.Style.STROKE
        p.strokeWidth = 0.008f * W
        p.color = 0xFFD7DBE0.toInt()
        c.drawCircle(recordX, recordY, lr, p)

        // lubang tengah
        p.style = Paint.Style.FILL
        p.color = 0xFF0B0B0E.toInt()
        c.drawCircle(recordX, recordY, 0.02f * W, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 0.003f * W
        p.color = 0xFFB8BEC8.toInt()
        c.drawCircle(recordX, recordY, 0.02f * W, p)

        drawArm(c, W)
    }

    private fun drawArm(c: Canvas, W: Float) {
        // rumah pangkal
        p.style = Paint.Style.FILL
        p.color = 0x55000000
        c.drawCircle(px + 0.008f * W, py + 0.012f * W, 0.078f * W, p)
        p.color = 0xFF22252B.toInt()
        c.drawCircle(px, py, 0.075f * W, p)
        p.color = 0xFF3A3F48.toInt()
        c.drawCircle(px, py, 0.052f * W, p)

        val tracking = -progress * TRACK * (1f - lift / LIFT)
        val ang = baseDeg + lift + tracking

        c.save()
        c.translate(px, py)
        c.rotate(ang)

        // bayangan lengan di atas piringan (makin jelas saat jarum menyentuh)
        val near = 1f - (lift / LIFT).coerceIn(0f, 1f)
        if (near > 0.05f) {
            p.style = Paint.Style.STROKE
            p.strokeCap = Paint.Cap.ROUND
            p.strokeWidth = 0.016f * W
            p.color = ((0x55 * near).toInt() shl 24)
            c.drawLine(0.006f * W, 0.016f * W, armLen * 0.88f + 0.006f * W, 0.016f * W, p)
        }

        // pemberat di belakang pangkal
        p.style = Paint.Style.FILL
        p.color = 0xFF9EA4AD.toInt()
        rect.set(-0.13f * W, -0.026f * W, -0.035f * W, 0.026f * W)
        c.drawRoundRect(rect, 0.012f * W, 0.012f * W, p)
        p.color = 0xFF2B2F36.toInt()
        rect.set(-0.085f * W, -0.027f * W, -0.07f * W, 0.027f * W)
        c.drawRect(rect, p)

        // tabung lengan
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 0.016f * W
        p.color = 0xFFC9CED6.toInt()
        c.drawLine(0f, 0f, armLen * 0.88f, 0f, p)
        p.strokeWidth = 0.005f * W
        p.color = 0xAAFFFFFF.toInt()
        c.drawLine(0f, -0.004f * W, armLen * 0.88f, -0.004f * W, p)

        // headshell + jarum
        c.save()
        c.translate(armLen * 0.88f, 0f)
        c.rotate(16f)
        p.style = Paint.Style.FILL
        p.color = 0xFF2B2F36.toInt()
        rect.set(-0.01f * W, -0.028f * W, 0.075f * W, 0.028f * W)
        c.drawRoundRect(rect, 0.012f * W, 0.012f * W, p)
        p.color = accent
        c.drawCircle(0.064f * W, 0f, 0.012f * W, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 0.003f * W
        p.color = 0xFF555B66.toInt()
        c.drawRoundRect(rect, 0.012f * W, 0.012f * W, p)
        c.restore()

        c.restore()

        // tutup pangkal (di atas lengan)
        p.style = Paint.Style.FILL
        p.color = 0xFFB8BEC8.toInt()
        c.drawCircle(px, py, 0.024f * W, p)
        p.color = 0xFF2B2F36.toInt()
        c.drawCircle(px, py, 0.01f * W, p)
    }

    override fun onDetachedFromWindow() {
        spinAnim.cancel()
        armAnim?.cancel()
        super.onDetachedFromWindow()
    }

    companion object {
        private const val LIFT = 32f   // derajat jarum terangkat
        private const val TRACK = 9f   // derajat geser jarum dari awal sampai akhir lagu
    }
}
