package com.nada.player

import android.Manifest
import android.animation.ObjectAnimator
import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import java.util.concurrent.Executors

/** Satu baris di daftar: sebuah lagu, atau sebuah grup (album / artis). */
class Row(
    val title: String,
    val subtitle: String,
    val thumb: Track,
    val tracks: List<Track>,
    val isGroup: Boolean
)

class MainActivity : Activity() {

    private var service: PlayerService? = null
    private var allTracks: List<Track> = emptyList()
    private var rows: List<Row> = emptyList()

    private var tab = 0                         // 0 Lagu, 1 Album, 2 Artis, 3 Favorit
    private var groupTitle: String? = null
    private var groupTracks: List<Track> = emptyList()
    private var query = ""

    private lateinit var headerTitle: TextView
    private lateinit var headerSub: TextView
    private lateinit var backBtn: IconView
    private lateinit var searchBtn: IconView
    private lateinit var searchBox: EditText
    private lateinit var tabViews: List<TextView>
    private lateinit var tabLines: List<View>
    private lateinit var list: ListView
    private lateinit var mini: LinearLayout
    private lateinit var miniThumb: ImageView
    private lateinit var miniTitle: TextView
    private lateinit var miniArtist: TextView
    private lateinit var miniBtn: IconView
    private lateinit var now: NowPlayingView
    private val adapter = RowAdapter()

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName, b: IBinder) {
            val s = (b as PlayerService.LocalBinder).get()
            service = s
            s.onChange = { onPlayerChange() }
            now.service = s
            onPlayerChange()
        }
        override fun onServiceDisconnected(n: ComponentName) { service = null; now.service = null }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Favorites.init(this)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        buildUi()
        bindService(Intent(this, PlayerService::class.java), conn, Context.BIND_AUTO_CREATE)
        requestPerms()
    }

    // ---------- UI ----------
    private fun round(v: View, radiusDp: Int) {
        val r = dp(radiusDp).toFloat()
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) { outline.setRoundRect(0, 0, view.width, view.height, r) }
        }
        v.clipToOutline = true
    }

    private fun buildUi() {
        val root = FrameLayout(this)
        root.setBackgroundColor(BG)
        root.fitsSystemWindows = true

        val library = LinearLayout(this)
        library.orientation = LinearLayout.VERTICAL

        // header
        backBtn = IconView(this, Ic.BACK)
        backBtn.visibility = View.GONE
        backBtn.setOnClickListener { leaveGroup() }
        headerTitle = TextView(this)
        headerTitle.text = "Nada"
        headerTitle.textSize = 26f
        headerTitle.setTextColor(Color.WHITE)
        headerTitle.typeface = Typeface.DEFAULT_BOLD
        headerTitle.setSingleLine(true)
        headerTitle.ellipsize = TextUtils.TruncateAt.END
        headerSub = TextView(this)
        headerSub.textSize = 13f
        headerSub.setTextColor(MUTED)
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.addView(headerTitle)
        titles.addView(headerSub)
        searchBtn = IconView(this, Ic.SEARCH)
        searchBtn.setOnClickListener { toggleSearch() }
        val header = LinearLayout(this)
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(dp(8), dp(12), dp(8), dp(4))
        header.addView(backBtn, LinearLayout.LayoutParams(dp(44), dp(44)))
        header.addView(titles, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(12) })
        header.addView(searchBtn, LinearLayout.LayoutParams(dp(48), dp(48)))
        library.addView(header, LinearLayout.LayoutParams(MATCH, WRAP))

        // kotak pencarian
        searchBox = EditText(this)
        searchBox.hint = "Cari judul, artis, atau album…"
        searchBox.setHintTextColor(MUTED)
        searchBox.setTextColor(Color.WHITE)
        searchBox.textSize = 15f
        searchBox.setSingleLine(true)
        searchBox.setPadding(dp(16), dp(10), dp(16), dp(10))
        val sb = GradientDrawable()
        sb.setColor(CARD)
        sb.cornerRadius = dp(12).toFloat()
        searchBox.background = sb
        searchBox.visibility = View.GONE
        searchBox.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { query = s?.toString() ?: ""; rebuild() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        library.addView(searchBox, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dp(16), dp(4), dp(16), dp(4)) })

        // tab
        val names = listOf("Lagu", "Album", "Artis", "Favorit")
        val tv = ArrayList<TextView>()
        val ln = ArrayList<View>()
        val tabRow = LinearLayout(this)
        tabRow.setPadding(dp(8), dp(4), dp(8), 0)
        for ((i, name) in names.withIndex()) {
            val t = TextView(this)
            t.text = name
            t.textSize = 15f
            t.gravity = Gravity.CENTER
            t.setPadding(0, dp(12), 0, dp(10))
            val line = View(this)
            line.setBackgroundColor(GREEN)
            val cell = LinearLayout(this)
            cell.orientation = LinearLayout.VERTICAL
            cell.addView(t, LinearLayout.LayoutParams(MATCH, WRAP))
            cell.addView(line, LinearLayout.LayoutParams(dp(28), dp(3)).apply { gravity = Gravity.CENTER_HORIZONTAL })
            cell.setOnClickListener { selectTab(i) }
            tabRow.addView(cell, LinearLayout.LayoutParams(0, WRAP, 1f))
            tv.add(t); ln.add(line)
        }
        tabViews = tv
        tabLines = ln
        library.addView(tabRow, LinearLayout.LayoutParams(MATCH, WRAP))

        // daftar
        list = ListView(this)
        list.adapter = adapter
        list.divider = null
        list.setOnItemClickListener { _, _, pos, _ -> onRowClick(pos) }
        library.addView(list, LinearLayout.LayoutParams(MATCH, 0, 1f))

        // mini player
        miniThumb = ImageView(this)
        miniThumb.scaleType = ImageView.ScaleType.CENTER_CROP
        round(miniThumb, 10)
        miniTitle = TextView(this)
        miniTitle.setTextColor(Color.WHITE)
        miniTitle.textSize = 15f
        miniTitle.typeface = Typeface.DEFAULT_BOLD
        miniTitle.setSingleLine(true)
        miniTitle.ellipsize = TextUtils.TruncateAt.END
        miniArtist = TextView(this)
        miniArtist.setTextColor(GREEN)
        miniArtist.textSize = 12f
        miniArtist.setSingleLine(true)
        miniArtist.ellipsize = TextUtils.TruncateAt.END
        miniBtn = IconView(this, Ic.PLAY)
        miniBtn.tint = GREEN
        miniBtn.iconScale = 0.3f
        miniBtn.setOnClickListener { service?.toggle() }
        val miniTexts = LinearLayout(this)
        miniTexts.orientation = LinearLayout.VERTICAL
        miniTexts.addView(miniTitle)
        miniTexts.addView(miniArtist)
        mini = LinearLayout(this)
        mini.gravity = Gravity.CENTER_VERTICAL
        mini.setBackgroundColor(CARD)
        mini.setPadding(dp(12), dp(8), dp(8), dp(8))
        mini.visibility = View.GONE
        mini.setOnClickListener { openNowPlaying() }
        mini.addView(miniThumb, LinearLayout.LayoutParams(dp(44), dp(44)))
        mini.addView(miniTexts, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(12) })
        mini.addView(miniBtn, LinearLayout.LayoutParams(dp(52), dp(52)))
        library.addView(mini, LinearLayout.LayoutParams(MATCH, WRAP))

        now = NowPlayingView(this)
        now.visibility = View.GONE
        now.onClose = { closeNowPlaying() }

        root.addView(library, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(now, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(root)
        updateTabs()
    }

    private fun updateTabs() {
        for (i in tabViews.indices) {
            val on = i == tab && groupTitle == null
            tabViews[i].setTextColor(if (on) Color.WHITE else MUTED)
            tabViews[i].typeface = if (on) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            tabLines[i].visibility = if (on) View.VISIBLE else View.INVISIBLE
        }
    }

    private fun selectTab(i: Int) {
        tab = i
        groupTitle = null
        rebuild()
    }

    private fun leaveGroup() { groupTitle = null; rebuild() }

    private fun toggleSearch() {
        if (searchBox.visibility == View.VISIBLE) {
            searchBox.setText("")
            searchBox.visibility = View.GONE
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(searchBox.windowToken, 0)
        } else {
            searchBox.visibility = View.VISIBLE
            searchBox.requestFocus()
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(searchBox, 0)
        }
    }

    // ---------- data daftar ----------
    private fun rebuild() {
        val q = query.trim().lowercase()
        fun match(t: Track) = q.isEmpty() || t.title.lowercase().contains(q) ||
            t.artist.lowercase().contains(q) || t.album.lowercase().contains(q)
        fun trackRow(t: Track) = Row(t.title, "${t.artist} • ${fmtTime(t.durationMs.toInt())}", t, listOf(t), false)

        rows = when {
            groupTitle != null -> groupTracks.filter { match(it) }.map { trackRow(it) }
            tab == 0 -> allTracks.filter { match(it) }.map { trackRow(it) }
            tab == 1 -> allTracks.filter { match(it) }.groupBy { it.album }.map { (k, v) ->
                Row(k, "${v.size} lagu • ${v[0].artist}", v[0], v, true)
            }.sortedBy { it.title.lowercase() }
            tab == 2 -> allTracks.filter { match(it) }.groupBy { it.artist }.map { (k, v) ->
                Row(k, "${v.size} lagu", v[0], v, true)
            }.sortedBy { it.title.lowercase() }
            else -> allTracks.filter { Favorites.has(it.id) && match(it) }.map { trackRow(it) }
        }

        val inGroup = groupTitle != null
        backBtn.visibility = if (inGroup) View.VISIBLE else View.GONE
        headerTitle.text = groupTitle ?: "Nada"
        headerSub.text = when {
            allTracks.isEmpty() -> "Tidak ada lagu. Salin file MP3 ke folder Music lalu buka ulang."
            rows.isEmpty() && tab == 3 && !inGroup -> "Belum ada favorit — ketuk ♥ di layar pemutar"
            else -> "${rows.size} ${if (rows.firstOrNull()?.isGroup == true) "grup" else "lagu"}"
        }
        updateTabs()
        adapter.notifyDataSetChanged()
    }

    private fun onRowClick(pos: Int) {
        val r = rows.getOrNull(pos) ?: return
        if (r.isGroup) {
            groupTitle = r.title
            groupTracks = r.tracks
            query = ""
            searchBox.setText("")
            rebuild()
        } else {
            val queue = rows.filter { !it.isGroup }.map { it.thumb }
            play(queue, queue.indexOfFirst { it.id == r.thumb.id })
        }
    }

    private inner class RowAdapter : BaseAdapter() {
        override fun getCount() = rows.size
        override fun getItem(position: Int): Any = rows[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val h: Holder
            val v: View
            if (convertView == null) {
                h = Holder(this@MainActivity)
                v = h.root
                v.tag = h
            } else {
                v = convertView
                h = convertView.tag as Holder
            }
            val r = rows[position]
            val playing = !r.isGroup && service?.current?.id == r.thumb.id
            h.title.text = r.title
            h.title.setTextColor(if (playing) GREEN else Color.WHITE)
            h.sub.text = r.subtitle
            h.wave.visibility = if (playing) View.VISIBLE else View.GONE
            h.thumb.tag = r.thumb.id
            h.thumb.setImageDrawable(ColorDrawable(CARD))
            Thumbs.load(this@MainActivity, r.thumb, 128) { bmp ->
                if (h.thumb.tag == r.thumb.id) h.thumb.setImageBitmap(bmp)
            }
            return v
        }
    }

    private inner class Holder(c: Context) {
        val thumb = ImageView(c)
        val title = TextView(c)
        val sub = TextView(c)
        val wave = IconView(c, Ic.WAVE)
        val root = LinearLayout(c)

        init {
            thumb.scaleType = ImageView.ScaleType.CENTER_CROP
            round(thumb, 10)
            title.textSize = 15f
            title.setSingleLine(true)
            title.ellipsize = TextUtils.TruncateAt.END
            sub.textSize = 12f
            sub.setTextColor(MUTED)
            sub.setSingleLine(true)
            sub.ellipsize = TextUtils.TruncateAt.END
            wave.tint = GREEN
            val texts = LinearLayout(c)
            texts.orientation = LinearLayout.VERTICAL
            texts.addView(title)
            texts.addView(sub)
            root.gravity = Gravity.CENTER_VERTICAL
            root.setPadding(c.dp(16), c.dp(8), c.dp(12), c.dp(8))
            root.addView(thumb, LinearLayout.LayoutParams(c.dp(52), c.dp(52)))
            root.addView(texts, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = c.dp(14) })
            root.addView(wave, LinearLayout.LayoutParams(c.dp(32), c.dp(32)))
        }
    }

    // ---------- izin & muat lagu ----------
    private fun audioPerm() =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun requestPerms() {
        val want = mutableListOf(audioPerm(), Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) want += Manifest.permission.POST_NOTIFICATIONS
        val missing = want.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) loadLibrary() else requestPermissions(missing.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (checkSelfPermission(audioPerm()) == PackageManager.PERMISSION_GRANTED) loadLibrary()
        else headerSub.text = "Izin membaca musik diperlukan untuk menampilkan daftar lagu."
    }

    private fun loadLibrary() {
        Executors.newSingleThreadExecutor().execute {
            val found = Library.load(this)
            runOnUiThread { allTracks = found; rebuild() }
        }
    }

    // ---------- pemutaran ----------
    private fun play(queue: List<Track>, pos: Int) {
        val s = service ?: return
        if (pos < 0) return
        startForegroundService(Intent(this, PlayerService::class.java))
        s.setQueue(queue)
        s.playAt(pos)
        openNowPlaying()
    }

    private fun onPlayerChange() {
        val s = service ?: return
        val t = s.current
        if (t == null) mini.visibility = View.GONE
        else {
            mini.visibility = View.VISIBLE
            miniTitle.text = t.title
            miniArtist.text = t.artist
            miniBtn.kind = if (s.isPlaying) Ic.PAUSE else Ic.PLAY
            miniThumb.tag = t.id
            Thumbs.load(this, t, 128) { bmp -> if (miniThumb.tag == t.id) miniThumb.setImageBitmap(bmp) }
        }
        adapter.notifyDataSetChanged()
        now.refresh()
    }

    private fun openNowPlaying() {
        if (service?.current == null) return
        now.visibility = View.VISIBLE
        now.show()
        ObjectAnimator.ofFloat(now, View.ALPHA, 0f, 1f).setDuration(250).start()
    }

    private fun closeNowPlaying() {
        now.hide()
        now.visibility = View.GONE
        rebuild()   // favorit mungkin berubah
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            now.visibility == View.VISIBLE -> closeNowPlaying()
            searchBox.visibility == View.VISIBLE -> toggleSearch()
            groupTitle != null -> leaveGroup()
            else -> super.onBackPressed()
        }
    }

    override fun onDestroy() {
        now.hide()
        service?.onChange = null
        try { unbindService(conn) } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()
}
