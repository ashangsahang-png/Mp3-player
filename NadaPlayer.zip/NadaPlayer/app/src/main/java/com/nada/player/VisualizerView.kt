package com.nada.player

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Visualizer di latar belakang, digerakkan data FFT dari android.media.audiofx.Visualizer.
 * style 0 = cincin di sekeliling cover, 1 = gelombang neon, 2 = batang di bawah.
 */
class VisualizerView(ctx: Context) : View(ctx) {

    private val bars = 48
    private val target = FloatArray(bars)
    private val level = FloatArray(bars)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()
    private val d = ctx.resources.displayMetrics.density
    private var phase = 0f
    private var ringX = 0f
    private var ringY = 0f
    private var ringR = 0f

    var accent: Int = GREEN
    var style: Int = 0
        set(v) { field = v; invalidate() }

    fun setRing(cx: Float, cy: Float, r: Float) { ringX = cx; ringY = cy; ringR = r; invalidate() }

    fun feed(fft: ByteArray) {
        val n = fft.size / 2            // jumlah bin kompleks
        if (n < 8) return
        val top = n / 2                 // pakai separuh bawah spektrum (~0–11 kHz)
        for (b in 0 until bars) {
            val lo = 1 + ((top - 1) * Math.pow(b.toDouble() / bars, 2.0)).toInt()
            val hi = maxOf(lo + 1, 1 + ((top - 1) * Math.pow((b + 1).toDouble() / bars, 2.0)).toInt())
            var sum = 0f
            var cnt = 0
            for (k in lo until minOf(hi, n)) {
                val re = fft[2 * k].toDouble()
                val im = fft[2 * k + 1].toDouble()
                sum += Math.hypot(re, im).toFloat()
                cnt++
            }
            val m = if (cnt == 0) 0f else sum / cnt
            val v = Math.sqrt((m / 90f).toDouble()).toFloat() * (1f + 0.8f * b / bars)
            target[b] = v.coerceIn(0f, 1f)
        }
        postInvalidateOnAnimation()
    }

    override fun onDraw(c: Canvas) {
        var active = false
        for (i in 0 until bars) {
            val t = target[i]
            level[i] += (t - level[i]) * (if (t > level[i]) 0.6f else 0.18f)
            target[i] = t * 0.9f
            if (level[i] > 0.004f) active = true
        }
        when (style) {
            0 -> drawRing(c)
            1 -> drawWave(c, active)
            else -> drawBars(c)
        }
        if (active) postInvalidateOnAnimation()
    }

    private fun drawRing(c: Canvas) {
        if (ringR <= 0f) return
        // lingkaran titik-titik tipis
        paint.style = Paint.Style.FILL
        paint.color = accent
        paint.alpha = 110
        val dots = 96
        for (i in 0 until dots) {
            val a = i * 2.0 * PI / dots
            c.drawCircle(ringX + (cos(a) * ringR * 1.05).toFloat(), ringY + (sin(a) * ringR * 1.05).toFloat(), 1.2f * d, paint)
        }
        // batang radial, simetris kiri-kanan
        val n = 72
        val half = n / 2
        val inner = ringR * 1.12f
        val maxLen = ringR * 0.34f
        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeWidth = 2.6f * d
        for (i in 0 until n) {
            val k = if (i < half) i else n - 1 - i
            val lv = level[(k * bars / half).coerceAtMost(bars - 1)]
            val a = -PI / 2 + i * 2.0 * PI / n
            val len = 3f * d + lv * maxLen
            paint.color = accent
            paint.alpha = (120 + 120 * lv).toInt().coerceAtMost(240)
            val ca = cos(a).toFloat()
            val sa = sin(a).toFloat()
            c.drawLine(ringX + ca * inner, ringY + sa * inner, ringX + ca * (inner + len), ringY + sa * (inner + len), paint)
        }
    }

    private fun drawWave(c: Canvas, active: Boolean) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (active) phase += 0.09f
        val colors = intArrayOf(0xFFFF2DAA.toInt(), 0xFF00E5FF.toInt(), 0xFFFFD60A.toInt())
        val base = h * 0.8f
        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeJoin = Paint.Join.ROUND
        val steps = 64
        for (k in 0 until 3) {
            path.reset()
            for (s in 0..steps) {
                val t = s.toFloat() / steps
                val lv = level[(t * (bars - 1)).toInt()]
                val amp = h * 0.15f * (0.15f + 1.3f * lv)
                val y = base - (sin(2.0 * PI * t * (1.3 + 0.45 * k) + phase * (1.0 + 0.35 * k) + k * 1.7)).toFloat() * amp
                if (s == 0) path.moveTo(t * w, y) else path.lineTo(t * w, y)
            }
            paint.color = colors[k]
            paint.strokeWidth = 8f * d; paint.alpha = 55; c.drawPath(path, paint)
            paint.strokeWidth = 2.4f * d; paint.alpha = 235; c.drawPath(path, paint)
        }
    }

    private fun drawBars(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val slot = w / bars
        val bw = slot * 0.62f
        paint.style = Paint.Style.FILL
        for (i in 0 until bars) {
            val bh = level[i] * h * 0.5f
            if (bh < 2f) continue
            paint.color = accent
            paint.alpha = (110 + 110 * level[i]).toInt().coerceAtMost(230)
            val x = i * slot + (slot - bw) / 2f
            rect.set(x, h - bh, x + bw, h)
            c.drawRoundRect(rect, bw / 2f, bw / 2f, paint)
        }
    }
}
