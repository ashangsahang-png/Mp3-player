package com.nada.player

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.audiofx.AudioEffect
import android.media.audiofx.Visualizer
import android.os.Build
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors

/**
 * Layar pemutar penuh: latar blur dari cover MP3, cakram cover berputar dengan cincin visualizer,
 * tombol shuffle / prev / play / next / repeat, seekbar, favorit, timer tidur.
 */
class NowPlayingView(private val ctx: Context) : FrameLayout(ctx) {

    var service: PlayerService? = null
    var onClose: (() -> Unit)? = null

    private val bgView = ImageView(ctx)
    private val viz = VisualizerView(ctx)
    private val disc = DiscView(ctx)
    private val titleTv = TextView(ctx)
    private val artistTv = TextView(ctx)
    private val albumTv = TextView(ctx)
    private val curTv = TextView(ctx)
    private val durTv = TextView(ctx)
    private val seek = SeekBar(ctx)
    private val heart = IconView(ctx, Ic.HEART)
    private val more = IconView(ctx, Ic.MORE)
    private val shuffleBtn = IconView(ctx, Ic.SHUFFLE)
    private val prevBtn = IconView(ctx, Ic.PREV)
    private val playBtn = IconView(ctx, Ic.PAUSE)
    private val nextBtn = IconView(ctx, Ic.NEXT)
    private val repeatBtn = IconView(ctx, Ic.REPEAT)
    private val io = Executors.newSingleThreadExecutor()

    private var visualizer: Visualizer? = null
    private var shown = false
    private var dragging = false
    private var shownId = -1L
    private var shownSession = -1
    private var shownArt: Bitmap? = null

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val tick = object : Runnable {
        override fun run() {
            val s = service
            if (shown && s != null) {
                val d = s.duration
                if (d > 0 && seek.max != d) { seek.max = d; durTv.text = fmtTime(d) }
                if (!dragging) { seek.progress = s.position; curTv.text = fmtTime(s.position) }
            }
            if (shown) postDelayed(this, 250)
        }
    }

    init {
        setBackgroundColor(BG)

        // ---- latar: cover blur + gradasi gelap ----
        bgView.scaleType = ImageView.ScaleType.CENTER_CROP
        bgView.scaleX = 1.25f
        bgView.scaleY = 1.25f
        if (Build.VERSION.SDK_INT >= 31) {
            bgView.setRenderEffect(RenderEffect.createBlurEffect(24f, 24f, Shader.TileMode.CLAMP))
        }
        addView(bgView, FrameLayout.LayoutParams(MATCH, MATCH))
        val scrim = View(ctx)
        scrim.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(0x88000000.toInt(), 0xAA000000.toInt(), 0xEE05060F.toInt())
        )
        addView(scrim, FrameLayout.LayoutParams(MATCH, MATCH))
        addView(viz, FrameLayout.LayoutParams(MATCH, MATCH))

        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(ctx.dp(16), ctx.dp(8), ctx.dp(16), ctx.dp(20))

        // ---- header ----
        val back = IconView(ctx, Ic.BACK)
        back.setOnClickListener { onClose?.invoke() }
        titleTv.setTextColor(Color.WHITE)
        titleTv.textSize = 16f
        titleTv.typeface = Typeface.DEFAULT_BOLD
        titleTv.setSingleLine(true)
        titleTv.ellipsize = TextUtils.TruncateAt.END
        artistTv.setTextColor(0xCCFFFFFF.toInt())
        artistTv.textSize = 12f
        artistTv.setSingleLine(true)
        artistTv.ellipsize = TextUtils.TruncateAt.END
        val texts = LinearLayout(ctx)
        texts.orientation = LinearLayout.VERTICAL
        texts.addView(titleTv)
        texts.addView(artistTv)
        heart.setOnClickListener {
            val t = service?.current ?: return@setOnClickListener
            Favorites.toggle(t.id)
            refreshHeart(t)
        }
        more.setOnClickListener { showMenu() }
        val header = LinearLayout(ctx)
        header.gravity = Gravity.CENTER_VERTICAL
        header.addView(back, LinearLayout.LayoutParams(ctx.dp(48), ctx.dp(48)))
        header.addView(texts, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = ctx.dp(4) })
        header.addView(heart, LinearLayout.LayoutParams(ctx.dp(48), ctx.dp(48)))
        header.addView(more, LinearLayout.LayoutParams(ctx.dp(48), ctx.dp(48)))
        col.addView(header, LinearLayout.LayoutParams(MATCH, WRAP))

        // ---- cakram cover ----
        col.addView(View(ctx), LinearLayout.LayoutParams(MATCH, 0, 1f))
        val discSize = (ctx.resources.displayMetrics.widthPixels * 0.56f).toInt()
        col.addView(disc, LinearLayout.LayoutParams(discSize, discSize).apply { gravity = Gravity.CENTER_HORIZONTAL })
        disc.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> positionRing() }
        albumTv.setTextColor(GREEN)
        albumTv.textSize = 14f
        albumTv.gravity = Gravity.CENTER
        albumTv.setSingleLine(true)
        albumTv.ellipsize = TextUtils.TruncateAt.END
        col.addView(albumTv, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = ctx.dp(36) })
        col.addView(View(ctx), LinearLayout.LayoutParams(MATCH, 0, 1f))

        // ---- baris ikon: antrean, equalizer, volume, gaya visualizer ----
        val iconRow = LinearLayout(ctx)
        iconRow.gravity = Gravity.CENTER
        fun iconAction(icon: Ic, click: View.OnClickListener) {
            val v = IconView(ctx, icon)
            v.tint = GREEN
            v.setOnClickListener(click)
            iconRow.addView(v, LinearLayout.LayoutParams(0, ctx.dp(48), 1f))
        }
        iconAction(Ic.NOTE, View.OnClickListener { onClose?.invoke() })
        iconAction(Ic.EQ, View.OnClickListener { openEqualizer() })
        iconAction(Ic.VOLUME, View.OnClickListener { showVolume() })
        iconAction(Ic.WAVE, View.OnClickListener { cycleStyle() })
        col.addView(iconRow, LinearLayout.LayoutParams(MATCH, WRAP))

        // ---- seekbar ----
        seek.progressTintList = ColorStateList.valueOf(GREEN)
        seek.thumbTintList = ColorStateList.valueOf(GREEN)
        seek.progressBackgroundTintList = ColorStateList.valueOf(0x44FFFFFF)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) { if (fromUser) curTv.text = fmtTime(p) }
            override fun onStartTrackingTouch(sb: SeekBar) { dragging = true }
            override fun onStopTrackingTouch(sb: SeekBar) { service?.seekTo(sb.progress); dragging = false }
        })
        col.addView(seek, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = ctx.dp(8) })
        for (t in listOf(curTv, durTv)) { t.setTextColor(0xCCFFFFFF.toInt()); t.textSize = 12f; t.text = "0:00" }
        val times = LinearLayout(ctx)
        times.setPadding(ctx.dp(16), 0, ctx.dp(16), 0)
        times.addView(curTv, LinearLayout.LayoutParams(0, WRAP, 1f))
        times.addView(durTv)
        col.addView(times, LinearLayout.LayoutParams(MATCH, WRAP))

        // ---- kontrol ----
        shuffleBtn.setOnClickListener { service?.toggleShuffle() }
        prevBtn.setOnClickListener { service?.prev() }
        nextBtn.setOnClickListener { service?.next() }
        repeatBtn.setOnClickListener { service?.cycleRepeat() }
        playBtn.setOnClickListener { service?.toggle() }
        playBtn.tint = BG
        playBtn.iconScale = 0.22f
        val circle = GradientDrawable()
        circle.shape = GradientDrawable.OVAL
        circle.setColor(GREEN)
        playBtn.background = circle

        val controls = LinearLayout(ctx)
        controls.gravity = Gravity.CENTER_VERTICAL
        controls.addView(cell(shuffleBtn, 52), LinearLayout.LayoutParams(0, ctx.dp(80), 1f))
        controls.addView(cell(prevBtn, 60), LinearLayout.LayoutParams(0, ctx.dp(80), 1f))
        controls.addView(cell(playBtn, 72), LinearLayout.LayoutParams(0, ctx.dp(80), 1.2f))
        controls.addView(cell(nextBtn, 60), LinearLayout.LayoutParams(0, ctx.dp(80), 1f))
        controls.addView(cell(repeatBtn, 52), LinearLayout.LayoutParams(0, ctx.dp(80), 1f))
        col.addView(controls, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = ctx.dp(8) })

        addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun cell(v: View, sizeDp: Int): FrameLayout {
        val f = FrameLayout(ctx)
        f.addView(v, FrameLayout.LayoutParams(ctx.dp(sizeDp), ctx.dp(sizeDp), Gravity.CENTER))
        return f
    }

    fun show() {
        shown = true
        shownSession = -1
        shownArt = null
        refresh()
        positionRing()
        removeCallbacks(tick)
        post(tick)
    }

    fun hide() {
        shown = false
        removeCallbacks(tick)
        releaseVisualizer()
        shownSession = -1
    }

    /** Dipanggil setiap kali service melapor perubahan (lagu ganti, play/pause, cover siap). */
    fun refresh() {
        if (!shown) return
        val s = service ?: return
        val t = s.current ?: return
        if (t.id != shownId) {
            shownId = t.id
            titleTv.text = t.title
            artistTv.text = t.artist
            albumTv.text = t.album
            seek.progress = 0
            curTv.text = "0:00"
            refreshHeart(t)
        }
        val d = s.duration
        if (d > 0 && seek.max != d) { seek.max = d; durTv.text = fmtTime(d) }
        val session = s.audioSessionId
        if (session != shownSession) { shownSession = session; attachVisualizer() }
        val a = s.art
        if (a != null && a !== shownArt) { shownArt = a; applyArt(a) }
        disc.setSpinning(s.isPlaying)
        playBtn.kind = if (s.isPlaying) Ic.PAUSE else Ic.PLAY
        shuffleBtn.tint = if (s.shuffle) GREEN else 0xAAFFFFFF.toInt()
        repeatBtn.kind = if (s.repeat == 2) Ic.REPEAT_ONE else Ic.REPEAT
        repeatBtn.tint = if (s.repeat == 0) 0xAAFFFFFF.toInt() else GREEN
    }

    private fun refreshHeart(t: Track) {
        heart.kind = if (Favorites.has(t.id)) Ic.HEART_FILLED else Ic.HEART
    }

    private fun applyArt(bmp: Bitmap) {
        disc.art = bmp
        io.execute {
            val blurred = Art.blur(bmp)
            val accent = Art.accent(bmp)
            post {
                viz.accent = accent
                bgView.animate().alpha(0f).setDuration(150).withEndAction {
                    bgView.setImageBitmap(blurred)
                    bgView.animate().alpha(1f).setDuration(400).start()
                }.start()
            }
        }
    }

    private fun positionRing() {
        if (disc.width == 0) return
        val a = IntArray(2)
        val b = IntArray(2)
        disc.getLocationInWindow(a)
        viz.getLocationInWindow(b)
        viz.setRing(a[0] - b[0] + disc.width / 2f, a[1] - b[1] + disc.height / 2f, disc.width / 2f)
    }

    // ---------- tombol ikon ----------
    private fun cycleStyle() {
        viz.style = (viz.style + 1) % 3
        val name = when (viz.style) { 0 -> "Cincin"; 1 -> "Gelombang neon"; else -> "Batang" }
        Toast.makeText(ctx, "Visualizer: $name", Toast.LENGTH_SHORT).show()
    }

    private fun showVolume() {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_SAME, AudioManager.FLAG_SHOW_UI)
    }

    private fun openEqualizer() {
        val sid = service?.audioSessionId ?: 0
        try {
            val i = Intent(AudioEffect.ACTION_DISPLAY_AUDIO_EFFECT_CONTROL_PANEL)
            i.putExtra(AudioEffect.EXTRA_AUDIO_SESSION, sid)
            i.putExtra(AudioEffect.EXTRA_PACKAGE_NAME, ctx.packageName)
            i.putExtra(AudioEffect.EXTRA_CONTENT_TYPE, AudioEffect.CONTENT_TYPE_MUSIC)
            ctx.startActivity(i)
        } catch (_: Exception) {
            Toast.makeText(ctx, "Equalizer tidak tersedia di perangkat ini", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showMenu() {
        val pm = PopupMenu(ctx, more)
        pm.menu.add(0, 15, 0, "Timer tidur 15 menit")
        pm.menu.add(0, 30, 1, "Timer tidur 30 menit")
        pm.menu.add(0, 60, 2, "Timer tidur 60 menit")
        pm.menu.add(0, 0, 3, "Matikan timer tidur")
        pm.setOnMenuItemClickListener { item ->
            val min = item.itemId
            service?.setSleepTimer(min)
            Toast.makeText(
                ctx, if (min > 0) "Musik berhenti otomatis dalam $min menit" else "Timer tidur dimatikan",
                Toast.LENGTH_SHORT
            ).show()
            true
        }
        pm.show()
    }

    // ---------- visualizer ----------
    private fun attachVisualizer() {
        releaseVisualizer()
        val s = service ?: return
        val sid = s.audioSessionId
        if (sid == 0) return
        if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        try {
            val v = Visualizer(sid)
            v.setCaptureSize(Visualizer.getCaptureSizeRange()[1].coerceAtMost(1024))
            v.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(vis: Visualizer?, wave: ByteArray?, rate: Int) {}
                override fun onFftDataCapture(vis: Visualizer?, fft: ByteArray?, rate: Int) { if (fft != null) viz.feed(fft) }
            }, Visualizer.getMaxCaptureRate() / 2, false, true)
            v.setEnabled(true)
            visualizer = v
        } catch (_: Exception) {
            visualizer = null
        }
    }

    private fun releaseVisualizer() {
        try { visualizer?.setEnabled(false); visualizer?.release() } catch (_: Exception) {}
        visualizer = null
    }
}
