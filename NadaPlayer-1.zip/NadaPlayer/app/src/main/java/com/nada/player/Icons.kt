package com.nada.player

import android.content.Context
import android.graphics.*
import android.view.View

enum class Ic { PLAY, PAUSE, PREV, NEXT, SHUFFLE, REPEAT, REPEAT_ONE, HEART, HEART_FILLED, BACK, MORE, NOTE, EQ, VOLUME, WAVE, QUEUE, SEARCH }

/** Ikon digambar langsung dengan Canvas (koordinat -1..1), jadi tidak perlu file gambar. */
class IconView(ctx: Context, kind: Ic = Ic.PLAY) : View(ctx) {

    var kind: Ic = kind
        set(v) { field = v; invalidate() }
    var tint: Int = Color.WHITE
        set(v) { field = v; invalidate() }
    /** Setengah lebar ikon sebagai pecahan dari sisi terkecil view. */
    var iconScale: Float = 0.25f

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height) * iconScale
        c.save()
        c.translate(width / 2f, height / 2f)
        c.scale(s, s)
        p.color = if (kind == Ic.HEART_FILLED) 0xFFFF4D6D.toInt() else tint
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.strokeWidth = 0.17f
        drawIcon(c)
        c.restore()
    }

    private fun fill() { p.style = Paint.Style.FILL }
    private fun stroke() { p.style = Paint.Style.STROKE }

    private fun tri(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float) {
        path.reset(); path.moveTo(x1, y1); path.lineTo(x2, y2); path.lineTo(x3, y3); path.close()
        fill(); c.drawPath(path, p)
    }

    private fun drawIcon(c: Canvas) {
        when (kind) {
            Ic.PLAY -> tri(c, -0.65f, -0.9f, 0.95f, 0f, -0.65f, 0.9f)
            Ic.PAUSE -> {
                fill()
                c.drawRoundRect(-0.75f, -0.85f, -0.2f, 0.85f, 0.1f, 0.1f, p)
                c.drawRoundRect(0.2f, -0.85f, 0.75f, 0.85f, 0.1f, 0.1f, p)
            }
            Ic.PREV -> {
                fill(); c.drawRoundRect(-0.95f, -0.8f, -0.68f, 0.8f, 0.08f, 0.08f, p)
                tri(c, 0.95f, -0.8f, -0.5f, 0f, 0.95f, 0.8f)
            }
            Ic.NEXT -> {
                fill(); c.drawRoundRect(0.68f, -0.8f, 0.95f, 0.8f, 0.08f, 0.08f, p)
                tri(c, -0.95f, -0.8f, 0.5f, 0f, -0.95f, 0.8f)
            }
            Ic.SHUFFLE -> {
                stroke()
                path.reset(); path.moveTo(-0.9f, -0.6f); path.lineTo(-0.35f, -0.6f)
                path.cubicTo(0.1f, -0.6f, 0.1f, 0.6f, 0.5f, 0.6f); c.drawPath(path, p)
                path.reset(); path.moveTo(-0.9f, 0.6f); path.lineTo(-0.35f, 0.6f)
                path.cubicTo(0.1f, 0.6f, 0.1f, -0.6f, 0.5f, -0.6f); c.drawPath(path, p)
                tri(c, 0.45f, 0.95f, 0.98f, 0.6f, 0.45f, 0.25f)
                tri(c, 0.45f, -0.25f, 0.98f, -0.6f, 0.45f, -0.95f)
            }
            Ic.REPEAT, Ic.REPEAT_ONE -> {
                stroke()
                path.reset(); path.moveTo(0.3f, -0.55f); path.lineTo(-0.5f, -0.55f)
                path.quadTo(-0.85f, -0.55f, -0.85f, -0.2f); path.lineTo(-0.85f, 0.2f)
                path.quadTo(-0.85f, 0.55f, -0.5f, 0.55f); path.lineTo(0.5f, 0.55f)
                path.quadTo(0.85f, 0.55f, 0.85f, 0.2f); path.lineTo(0.85f, 0f)
                c.drawPath(path, p)
                tri(c, 0.25f, -0.95f, 0.85f, -0.55f, 0.25f, -0.15f)
                if (kind == Ic.REPEAT_ONE) {
                    stroke()
                    path.reset(); path.moveTo(-0.12f, -0.15f); path.lineTo(0.08f, -0.28f); path.lineTo(0.08f, 0.3f)
                    c.drawPath(path, p)
                }
            }
            Ic.HEART, Ic.HEART_FILLED -> {
                path.reset(); path.moveTo(0f, 0.85f)
                path.cubicTo(-1.25f, -0.05f, -0.75f, -0.95f, 0f, -0.35f)
                path.cubicTo(0.75f, -0.95f, 1.25f, -0.05f, 0f, 0.85f); path.close()
                if (kind == Ic.HEART) stroke() else fill()
                c.drawPath(path, p)
            }
            Ic.BACK -> {
                stroke()
                path.reset(); path.moveTo(0.85f, 0f); path.lineTo(-0.8f, 0f)
                path.moveTo(-0.1f, -0.7f); path.lineTo(-0.8f, 0f); path.lineTo(-0.1f, 0.7f)
                c.drawPath(path, p)
            }
            Ic.MORE -> { fill(); for (y in floatArrayOf(-0.7f, 0f, 0.7f)) c.drawCircle(0f, y, 0.14f, p) }
            Ic.NOTE -> {
                fill(); c.drawCircle(-0.4f, 0.55f, 0.36f, p)
                stroke()
                path.reset(); path.moveTo(-0.05f, 0.55f); path.lineTo(-0.05f, -0.85f)
                path.cubicTo(0.3f, -0.7f, 0.75f, -0.5f, 0.6f, 0.05f)
                c.drawPath(path, p)
            }
            Ic.EQ -> {
                stroke()
                for (x in floatArrayOf(-0.6f, 0f, 0.6f)) c.drawLine(x, -0.9f, x, 0.9f, p)
                fill()
                c.drawCircle(-0.6f, 0.3f, 0.22f, p); c.drawCircle(0f, -0.35f, 0.22f, p); c.drawCircle(0.6f, 0.15f, 0.22f, p)
            }
            Ic.VOLUME -> {
                path.reset(); path.moveTo(-0.95f, -0.32f); path.lineTo(-0.55f, -0.32f); path.lineTo(-0.05f, -0.8f)
                path.lineTo(-0.05f, 0.8f); path.lineTo(-0.55f, 0.32f); path.lineTo(-0.95f, 0.32f); path.close()
                fill(); c.drawPath(path, p)
                stroke()
                rect.set(-0.35f, -0.5f, 0.55f, 0.5f); c.drawArc(rect, -50f, 100f, false, p)
                rect.set(-0.55f, -0.95f, 0.95f, 0.95f); c.drawArc(rect, -45f, 90f, false, p)
            }
            Ic.WAVE -> {
                stroke()
                path.reset(); path.moveTo(-0.95f, 0f)
                path.cubicTo(-0.7f, -0.95f, -0.5f, -0.95f, -0.3f, 0f)
                path.cubicTo(-0.1f, 0.95f, 0.1f, 0.95f, 0.3f, 0f)
                path.cubicTo(0.5f, -0.95f, 0.7f, -0.95f, 0.95f, 0f)
                c.drawPath(path, p)
            }
            Ic.QUEUE -> {
                stroke()
                c.drawLine(-0.9f, -0.6f, 0.5f, -0.6f, p)
                c.drawLine(-0.9f, 0f, 0.5f, 0f, p)
                c.drawLine(-0.9f, 0.6f, -0.1f, 0.6f, p)
                tri(c, 0.2f, 0.2f, 0.95f, 0.6f, 0.2f, 1f)
            }
            Ic.SEARCH -> {
                stroke(); c.drawCircle(-0.15f, -0.15f, 0.6f, p)
                c.drawLine(0.3f, 0.3f, 0.9f, 0.9f, p)
            }
        }
    }
}
